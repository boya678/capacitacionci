<!--- app-name: Thanos -->

# Bitnami package for Thanos

Thanos is a highly available metrics system that can be added on top of existing Prometheus deployments, providing a global query view across all Prometheus installations.

[Overview of Thanos](https://thanos.io/)

Trademarks: This software listing is packaged by Bitnami. The respective trademarks mentioned in the offering are owned by the respective companies, and use of them does not imply any affiliation or endorsement.

## TL;DR

```console
helm install my-release oci://registry-1.docker.io/bitnamicharts/thanos
```

Looking to use Thanos in production? Try [VMware Tanzu Application Catalog](https://bitnami.com/enterprise), the enterprise edition of Bitnami Application Catalog.

## Introduction

This chart bootstraps a [Thanos](https://github.com/bitnami/containers/tree/main/bitnami/thanos) deployment on a [Kubernetes](https://kubernetes.io) cluster using the [Helm](https://helm.sh) package manager.

Bitnami charts can be used with [Kubeapps](https://kubeapps.dev/) for deployment and management of Helm Charts in clusters.

## Prerequisites

- Kubernetes 1.23+
- Helm 3.8.0+
- PV provisioner support in the underlying infrastructure

## Installing the Chart

To install the chart with the release name `my-release`:

```console
helm install my-release oci://REGISTRY_NAME/REPOSITORY_NAME/thanos
```

> Note: You need to substitute the placeholders `REGISTRY_NAME` and `REPOSITORY_NAME` with a reference to your Helm chart registry and repository. For example, in the case of Bitnami, you need to use `REGISTRY_NAME=registry-1.docker.io` and `REPOSITORY_NAME=bitnamicharts`.

These commands deploy Thanos on the Kubernetes cluster with the default configuration. The [configuration](#configuration-and-installation-details) section lists the parameters that can be configured during installation.

> **Tip**: List all releases using `helm list`

## Uninstalling the Chart

To uninstall/delete the `my-release` chart:

```console
helm uninstall my-release
```

## Architecture

This charts allows you install several Thanos components, so you deploy an architecture as the one below:

```text
                       +--------------+                  +--------------+      +--------------+
                       | Thanos       |----------------> | Thanos Store |      | Thanos       |
                       | Query        |           |      | Gateway      |      | Compactor    |
                       +--------------+           |      +--------------+      +--------------+
                   push                           |             |                     |
+--------------+   alerts   +--------------+      |             | storages            | Downsample &
| Alertmanager | <----------| Thanos       | <----|             | query metrics       | compact blocks
| (*)          |            | Ruler        |      |             |                     |
+--------------+            +--------------+      |             \/                    |
      ^                            |              |      +----------------+           |
      | push alerts                +--------------|----> | MinIO&reg; (*) | <---------+
      |                                           |      |                |
+------------------------------+                  |      +----------------+
|+------------+  +------------+|                  |             ^
|| Prometheus |->| Thanos     || <----------------+             |
|| (*)        |<-| Sidecar (*)||    query                       | inspect
|+------------+  +------------+|    metrics                     | blocks
+------------------------------+                                |
                                                         +--------------+
                                                         | Thanos       |
                                                         | Bucket Web   |
                                                         +--------------+
```

> Note: Components marked with (*) are provided by subchart(s) (such as the [Bitnami MinIO&reg; chart](https://github.com/bitnami/charts/tree/main/bitnami/minio)) or external charts (such as the [Bitnami kube-prometheus chart](https://github.com/bitnami/charts/tree/main/bitnami/kube-prometheus)).

Check the section [Integrate Thanos with Prometheus and Alertmanager](#integrate-thanos-with-prometheus-and-alertmanager) for detailed instructions to deploy this architecture.

## Parameters

### Global parameters

| Name                      | Description                                     | Value |
| ------------------------- | ----------------------------------------------- | ----- |
| `global.imageRegistry`    | Global Docker image registry                    | `""`  |
| `global.imagePullSecrets` | Global Docker registry secret names as an array | `[]`  |
| `global.storageClass`     | Global StorageClass for Persistent Volume(s)    | `""`  |

### Common parameters

| Name                | Description                                                                                  | Value           |
| ------------------- | -------------------------------------------------------------------------------------------- | --------------- |
| `kubeVersion`       | Force target Kubernetes version (using Helm capabilities if not set)                         | `""`            |
| `nameOverride`      | String to partially override common.names.fullname template (will maintain the release name) | `""`            |
| `fullnameOverride`  | String to fully override common.names.fullname template                                      | `""`            |
| `commonLabels`      | Add labels to all the deployed resources                                                     | `{}`            |
| `commonAnnotations` | Add annotations to all the deployed resources                                                | `{}`            |
| `clusterDomain`     | Kubernetes Cluster Domain                                                                    | `cluster.local` |
| `extraDeploy`       | Array of extra objects to deploy with the release                                            | `[]`            |

### Thanos common parameters

| Name                                          | Description                                                                                                         | Value                    |
| --------------------------------------------- | ------------------------------------------------------------------------------------------------------------------- | ------------------------ |
| `image.registry`                              | Thanos image registry                                                                                               | `REGISTRY_NAME`          |
| `image.repository`                            | Thanos image repository                                                                                             | `REPOSITORY_NAME/thanos` |
| `image.digest`                                | Thanos image digest in the way sha256:aa.... Please note this parameter, if set, will override the tag              | `""`                     |
| `image.pullPolicy`                            | Thanos image pull policy                                                                                            | `IfNotPresent`           |
| `image.pullSecrets`                           | Specify docker-registry secret names as an array                                                                    | `[]`                     |
| `objstoreConfig`                              | The [objstore configuration](https://thanos.io/tip/thanos/storage.md/)                                              | `""`                     |
| `indexCacheConfig`                            | The [index cache configuration](https://thanos.io/tip/components/store.md/)                                         | `""`                     |
| `bucketCacheConfig`                           | The [bucket cache configuration](https://thanos.io/tip/components/store.md/)                                        | `""`                     |
| `existingObjstoreSecret`                      | Secret with Objstore Configuration                                                                                  | `""`                     |
| `existingObjstoreSecretItems`                 | Optional item list for specifying a custom Secret key. If so, path should be objstore.yml                           | `[]`                     |
| `httpConfig`                                  | The [https and basic auth configuration](https://thanos.io/tip/operating/https.md/)                                 | `""`                     |
| `existingHttpConfigSecret`                    | Secret containing the HTTPS and Basic auth configuration                                                            | `""`                     |
| `https.enabled`                               | Set to true to enable HTTPS. Requires a secret containing the certificate and key.                                  | `false`                  |
| `https.autoGenerated`                         | Create self-signed TLS certificates.                                                                                | `false`                  |
| `https.existingSecret`                        | Existing secret containing your own server key and certificate                                                      | `""`                     |
| `https.certFilename`                          |                                                                                                                     | `tls.crt`                |
| `https.keyFilename`                           |                                                                                                                     | `tls.key`                |
| `https.caFilename`                            |                                                                                                                     | `ca.crt`                 |
| `https.key`                                   | TLS Key for Thanos HTTPS - ignored if existingSecret is provided                                                    | `""`                     |
| `https.cert`                                  | TLS Certificate for Thanos HTTPS - ignored if existingSecret is provided                                            | `""`                     |
| `https.ca`                                    | (Optional, used for client) CA Certificate for Thanos HTTPS - ignored if existingSecret is provided                 | `""`                     |
| `https.clientAuthType`                        | Server policy for client authentication using certificates. Maps to ClientAuth Policies.                            | `""`                     |
| `auth.basicAuthUsers`                         | Object containing <user>:<passwords> key-value pairs for each user that will have access via basic authentication   | `{}`                     |
| `serviceAccount.create`                       | Specifies whether a ServiceAccount should be created                                                                | `false`                  |
| `serviceAccount.name`                         | Name of the service account to use. If not set and create is true, a name is generated using the fullname template. | `""`                     |
| `serviceAccount.automountServiceAccountToken` | Automount service account token for the server service account                                                      | `true`                   |
| `serviceAccount.annotations`                  | Annotations for service account. Evaluated as a template. Only used if `create` is `true`.                          | `{}`                     |

### Thanos Query parameters

| Name                                                      | Description                                                                                                                             | Value                    |
| --------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------- | ------------------------ |
| `query.enabled`                                           | Set to true to enable Thanos Query component                                                                                            | `true`                   |
| `query.logLevel`                                          | Thanos Query log level                                                                                                                  | `info`                   |
| `query.logFormat`                                         | Thanos Query log format                                                                                                                 | `logfmt`                 |
| `query.replicaLabel`                                      | Replica indicator(s) along which data is de-duplicated                                                                                  | `["replica"]`            |
| `query.dnsDiscovery.enabled`                              | Enable store APIs discovery via DNS                                                                                                     | `true`                   |
| `query.dnsDiscovery.sidecarsService`                      | Sidecars service name to discover them using DNS discovery                                                                              | `""`                     |
| `query.dnsDiscovery.sidecarsNamespace`                    | Sidecars namespace to discover them using DNS discovery                                                                                 | `""`                     |
| `query.stores`                                            | Statically configure store APIs to connect with Thanos Query                                                                            | `[]`                     |
| `query.sdConfig`                                          | Query Service Discovery Configuration                                                                                                   | `""`                     |
| `query.existingSDConfigmap`                               | Name of existing ConfigMap with Ruler configuration                                                                                     | `""`                     |
| `query.extraEnvVars`                                      | Extra environment variables for Thanos Query container                                                                                  | `[]`                     |
| `query.extraEnvVarsCM`                                    | Name of existing ConfigMap containing extra env vars for Thanos Query nodes                                                             | `""`                     |
| `query.extraEnvVarsSecret`                                | Name of existing Secret containing extra env vars for Thanos Query nodes                                                                | `""`                     |
| `query.extraFlags`                                        | Extra Flags to passed to Thanos Query                                                                                                   | `[]`                     |
| `query.command`                                           | Override default container command (useful when using custom images)                                                                    | `[]`                     |
| `query.args`                                              | Override default container args (useful when using custom images)                                                                       | `[]`                     |
| `query.replicaCount`                                      | Number of Thanos Query replicas to deploy                                                                                               | `1`                      |
| `query.updateStrategy.type`                               | Update strategy type for Thanos Query replicas                                                                                          | `RollingUpdate`          |
| `query.podSecurityContext.enabled`                        | Enable security context for the Thanos Query pods                                                                                       | `true`                   |
| `query.podSecurityContext.fsGroup`                        | Group ID for the filesystem used by Thanos Query pods                                                                                   | `1001`                   |
| `query.containerSecurityContext.enabled`                  | Enabled containers' Security Context                                                                                                    | `true`                   |
| `query.containerSecurityContext.runAsUser`                | Set containers' Security Context runAsUser                                                                                              | `1001`                   |
| `query.containerSecurityContext.runAsNonRoot`             | Set container's Security Context runAsNonRoot                                                                                           | `true`                   |
| `query.containerSecurityContext.privileged`               | Set container's Security Context privileged                                                                                             | `false`                  |
| `query.containerSecurityContext.readOnlyRootFilesystem`   | Set container's Security Context readOnlyRootFilesystem                                                                                 | `true`                   |
| `query.containerSecurityContext.allowPrivilegeEscalation` | Set container's Security Context allowPrivilegeEscalation                                                                               | `false`                  |
| `query.containerSecurityContext.capabilities.drop`        | List of capabilities to be dropped                                                                                                      | `["ALL"]`                |
| `query.containerSecurityContext.seccompProfile.type`      | Set container's Security Context seccomp profile                                                                                        | `RuntimeDefault`         |
| `query.resources.limits`                                  | The resources limits for the Thanos Query container                                                                                     | `{}`                     |
| `query.resources.requests`                                | The requested resources for the Thanos Query container                                                                                  | `{}`                     |
| `query.livenessProbe.enabled`                             | Enable livenessProbe on Thanos Query containers                                                                                         | `true`                   |
| `query.livenessProbe.initialDelaySeconds`                 | Initial delay seconds for livenessProbe                                                                                                 | `30`                     |
| `query.livenessProbe.periodSeconds`                       | Period seconds for livenessProbe                                                                                                        | `10`                     |
| `query.livenessProbe.timeoutSeconds`                      | Timeout seconds for livenessProbe                                                                                                       | `30`                     |
| `query.livenessProbe.failureThreshold`                    | Failure threshold for livenessProbe                                                                                                     | `6`                      |
| `query.livenessProbe.successThreshold`                    | Success threshold for livenessProbe                                                                                                     | `1`                      |
| `query.readinessProbe.enabled`                            | Enable readinessProbe on Thanos Query containers                                                                                        | `true`                   |
| `query.readinessProbe.initialDelaySeconds`                | Initial delay seconds for readinessProbe                                                                                                | `30`                     |
| `query.readinessProbe.periodSeconds`                      | Period seconds for readinessProbe                                                                                                       | `10`                     |
| `query.readinessProbe.timeoutSeconds`                     | Timeout seconds for readinessProbe                                                                                                      | `30`                     |
| `query.readinessProbe.failureThreshold`                   | Failure threshold for readinessProbe                                                                                                    | `6`                      |
| `query.readinessProbe.successThreshold`                   | Success threshold for readinessProbe                                                                                                    | `1`                      |
| `query.startupProbe.enabled`                              | Enable startupProbe on Thanos Query containers                                                                                          | `false`                  |
| `query.startupProbe.initialDelaySeconds`                  | Initial delay seconds for startupProbe                                                                                                  | `5`                      |
| `query.startupProbe.periodSeconds`                        | Period seconds for startupProbe                                                                                                         | `5`                      |
| `query.startupProbe.timeoutSeconds`                       | Timeout seconds for startupProbe                                                                                                        | `1`                      |
| `query.startupProbe.failureThreshold`                     | Failure threshold for startupProbe                                                                                                      | `15`                     |
| `query.startupProbe.successThreshold`                     | Success threshold for startupProbe                                                                                                      | `1`                      |
| `query.customLivenessProbe`                               | Custom livenessProbe that overrides the default one                                                                                     | `{}`                     |
| `query.customReadinessProbe`                              | Custom readinessProbe that overrides the default one                                                                                    | `{}`                     |
| `query.customStartupProbe`                                | Custom startupProbe that overrides the default one                                                                                      | `{}`                     |
| `query.initContainers`                                    | Add additional init containers to the Thanos Query pods                                                                                 | `[]`                     |
| `query.sidecars`                                          | Extra containers running as sidecars to Thanos Query pods                                                                               | `[]`                     |
| `query.extraVolumes`                                      | Extra volumes to add to Thanos Query                                                                                                    | `[]`                     |
| `query.extraVolumeMounts`                                 | Extra volume mounts to add to the query container                                                                                       | `[]`                     |
| `query.podAffinityPreset`                                 | Thanos Query pod affinity preset                                                                                                        | `""`                     |
| `query.podAntiAffinityPreset`                             | Thanos Query pod anti-affinity preset. Ignored if `query.affinity` is set. Allowed values: `soft` or `hard`                             | `soft`                   |
| `query.podAntiAffinityPresetTopologyKey`                  | Thanos Query pod anti-affinity topologyKey. Ignored if `query.affinity` is set.                                                         | `""`                     |
| `query.nodeAffinityPreset.type`                           | Thanos Query node affinity preset type. Ignored if `query.affinity` is set. Allowed values: `soft` or `hard`                            | `""`                     |
| `query.nodeAffinityPreset.key`                            | Thanos Query node label key to match Ignored if `query.affinity` is set.                                                                | `""`                     |
| `query.nodeAffinityPreset.values`                         | Thanos Query node label values to match. Ignored if `query.affinity` is set.                                                            | `[]`                     |
| `query.affinity`                                          | Thanos Query affinity for pod assignment                                                                                                | `{}`                     |
| `query.nodeSelector`                                      | Thanos Query node labels for pod assignment                                                                                             | `{}`                     |
| `query.tolerations`                                       | Thanos Query tolerations for pod assignment                                                                                             | `[]`                     |
| `query.podLabels`                                         | Thanos Query pod labels                                                                                                                 | `{}`                     |
| `query.podAnnotations`                                    | Annotations for Thanos Query pods                                                                                                       | `{}`                     |
| `query.dnsConfig`                                         | Deployment pod DNS config                                                                                                               | `{}`                     |
| `query.dnsPolicy`                                         | Deployment pod DNS policy                                                                                                               | `""`                     |
| `query.hostAliases`                                       | Deployment pod host aliases                                                                                                             | `[]`                     |
| `query.lifecycleHooks`                                    | for the Thanos Query container(s) to automate configuration before or after startup                                                     | `{}`                     |
| `query.priorityClassName`                                 | Thanos Query priorityClassName                                                                                                          | `""`                     |
| `query.schedulerName`                                     | Name of the k8s scheduler (other than default) for Thanos Query pods                                                                    | `""`                     |
| `query.topologySpreadConstraints`                         | Topology Spread Constraints for Thanos Query pods assignment spread across your cluster among failure-domains                           | `[]`                     |
| `query.grpc.server.tls.enabled`                           | Enable TLS encryption in the GRPC server                                                                                                | `false`                  |
| `query.grpc.server.tls.autoGenerated`                     | Create self-signed TLS certificates. Currently only supports PEM certificates                                                           | `false`                  |
| `query.grpc.server.tls.cert`                              | TLS Certificate for GRPC server - ignored if existingSecret is provided                                                                 | `""`                     |
| `query.grpc.server.tls.key`                               | TLS Key for GRPC server - ignored if existingSecret is provided                                                                         | `""`                     |
| `query.grpc.server.tls.ca`                                | TLS CA to verify clients against - ignored if existingSecret is provided                                                                | `""`                     |
| `query.grpc.server.tls.existingSecret`                    | Existing secret containing your own TLS certificates                                                                                    | `{}`                     |
| `query.grpc.client.serverName`                            | Server name to verify the hostname on the returned GRPC certificates                                                                    | `""`                     |
| `query.grpc.client.tls.enabled`                           | Enable TLS encryption in the GRPC server                                                                                                | `false`                  |
| `query.grpc.client.tls.autoGenerated`                     | Create self-signed TLS certificates. Currently only supports PEM certificates                                                           | `false`                  |
| `query.grpc.client.tls.cert`                              | TLS Certificate for GRPC server - ignored if existingSecret is provided                                                                 | `""`                     |
| `query.grpc.client.tls.key`                               | TLS Key for GRPC server - ignored if existingSecret is provided                                                                         | `""`                     |
| `query.grpc.client.tls.ca`                                | TLS CA to verify clients against - ignored if existingSecret is provided                                                                | `""`                     |
| `query.grpc.client.tls.existingSecret`                    | Existing secret containing your own TLS certificates                                                                                    | `{}`                     |
| `query.service.type`                                      | Kubernetes service type                                                                                                                 | `ClusterIP`              |
| `query.service.ports.http`                                | Thanos Query service HTTP port                                                                                                          | `9090`                   |
| `query.service.nodePorts.http`                            | Specify the Thanos Query HTTP nodePort value for the LoadBalancer and NodePort service types                                            | `""`                     |
| `query.service.clusterIP`                                 | Thanos Query service clusterIP IP                                                                                                       | `""`                     |
| `query.service.loadBalancerIP`                            | Load balancer IP if service type is `LoadBalancer`                                                                                      | `""`                     |
| `query.service.loadBalancerSourceRanges`                  | Address that are allowed when service is LoadBalancer                                                                                   | `[]`                     |
| `query.service.externalTrafficPolicy`                     | Thanos Query service externalTrafficPolicy                                                                                              | `Cluster`                |
| `query.service.labels`                                    | Labels for Thanos Query service                                                                                                         | `{}`                     |
| `query.service.annotations`                               | Annotations for Thanos Query service                                                                                                    | `{}`                     |
| `query.service.extraPorts`                                | Extra ports to expose in the Thanos Query service                                                                                       | `[]`                     |
| `query.service.labelSelectorsOverride`                    | Selector for Thanos Query service                                                                                                       | `{}`                     |
| `query.service.additionalHeadless`                        | Additional Headless service                                                                                                             | `false`                  |
| `query.service.headless.annotations`                      | Annotations for the headless service.                                                                                                   | `{}`                     |
| `query.serviceGrpc.type`                                  | Kubernetes service type                                                                                                                 | `ClusterIP`              |
| `query.serviceGrpc.ports.grpc`                            | Thanos Query service GRPC port                                                                                                          | `10901`                  |
| `query.serviceGrpc.nodePorts.grpc`                        | Specify the Thanos Query GRPC nodePort value for the LoadBalancer and NodePort service types                                            | `""`                     |
| `query.serviceGrpc.clusterIP`                             | Thanos Query service clusterIP IP                                                                                                       | `""`                     |
| `query.serviceGrpc.loadBalancerIP`                        | Load balancer IP if service type is `LoadBalancer`                                                                                      | `""`                     |
| `query.serviceGrpc.loadBalancerSourceRanges`              | Address that are allowed when service is LoadBalancer                                                                                   | `[]`                     |
| `query.serviceGrpc.externalTrafficPolicy`                 | Thanos Query service externalTrafficPolicy                                                                                              | `Cluster`                |
| `query.serviceGrpc.annotations`                           | Annotations for Thanos Query service                                                                                                    | `{}`                     |
| `query.serviceGrpc.extraPorts`                            | Extra ports to expose in the Thanos Query service                                                                                       | `[]`                     |
| `query.serviceGrpc.labelSelectorsOverride`                | Selector for Thanos Query service                                                                                                       | `{}`                     |
| `query.serviceGrpc.additionalHeadless`                    | Additional Headless service                                                                                                             | `false`                  |
| `query.serviceGrpc.headless.annotations`                  | Annotations for the headless service.                                                                                                   | `{}`                     |
| `query.automountServiceAccountToken`                      | Enable/disable auto mounting of the service account token only for the deployment                                                       | `true`                   |
| `query.serviceAccount.create`                             | Specifies whether a ServiceAccount should be created                                                                                    | `true`                   |
| `query.serviceAccount.name`                               | Name of the service account to use. If not set and create is true, a name is generated using the fullname template.                     | `""`                     |
| `query.serviceAccount.annotations`                        | Annotations for Thanos Query Service Account                                                                                            | `{}`                     |
| `query.serviceAccount.automountServiceAccountToken`       | Enable/disable auto mounting of the service account token                                                                               | `true`                   |
| `query.rbac.create`                                       | Create a ClusterRole and ClusterRoleBinding for the Thanos Query Service Account                                                        | `false`                  |
| `query.rbac.rules`                                        | Custom RBAC rules to set                                                                                                                | `[]`                     |
| `query.pspEnabled`                                        | Whether to create a PodSecurityPolicy for Thanos Query                                                                                  | `false`                  |
| `query.autoscaling.enabled`                               | Enable autoscaling for Thanos Query                                                                                                     | `false`                  |
| `query.autoscaling.minReplicas`                           | Minimum number of Thanos Query replicas                                                                                                 | `""`                     |
| `query.autoscaling.maxReplicas`                           | Maximum number of Thanos Query replicas                                                                                                 | `""`                     |
| `query.autoscaling.targetCPU`                             | Target CPU utilization percentage                                                                                                       | `""`                     |
| `query.autoscaling.targetMemory`                          | Target Memory utilization percentage                                                                                                    | `""`                     |
| `query.pdb.create`                                        | Enable/disable a Pod Disruption Budget creation for Thanos Query                                                                        | `false`                  |
| `query.pdb.minAvailable`                                  | Minimum number/percentage of pods that should remain scheduled                                                                          | `1`                      |
| `query.pdb.maxUnavailable`                                | Maximum number/percentage of pods that may be made unavailable                                                                          | `""`                     |
| `query.ingress.enabled`                                   | Enable ingress controller resource                                                                                                      | `false`                  |
| `query.ingress.hostname`                                  | Default host for the ingress resource                                                                                                   | `thanos.local`           |
| `query.ingress.secretName`                                | Custom secretName for the ingress resource                                                                                              | `""`                     |
| `query.ingress.ingressClassName`                          | IngressClass that will be be used to implement the Ingress (Kubernetes 1.18+)                                                           | `""`                     |
| `query.ingress.annotations`                               | Additional annotations for the Ingress resource. To enable certificate autogeneration, place here your cert-manager annotations.        | `{}`                     |
| `query.ingress.extraHosts`                                | The list of additional hostnames to be covered with this ingress record.                                                                | `[]`                     |
| `query.ingress.extraTls`                                  | The tls configuration for additional hostnames to be covered with this ingress record.                                                  | `[]`                     |
| `query.ingress.secrets`                                   | If you're providing your own certificates, please use this to add the certificates as secrets                                           | `[]`                     |
| `query.ingress.extraRules`                                | Additional rules to be covered with this ingress record                                                                                 | `[]`                     |
| `query.ingress.tls`                                       | Enable TLS configuration for the hostname defined at `query.ingress.hostname` parameter                                                 | `false`                  |
| `query.ingress.selfSigned`                                | Create a TLS secret for this ingress record using self-signed certificates generated by Helm                                            | `false`                  |
| `query.ingress.apiVersion`                                | Force Ingress API version (automatically detected if not set)                                                                           | `""`                     |
| `query.ingress.path`                                      | Ingress path                                                                                                                            | `/`                      |
| `query.ingress.pathType`                                  | Ingress path type                                                                                                                       | `ImplementationSpecific` |
| `query.ingress.grpc.enabled`                              | Enable ingress controller resource (GRPC)                                                                                               | `false`                  |
| `query.ingress.grpc.hostname`                             | Default host for the ingress resource (GRPC)                                                                                            | `thanos-grpc.local`      |
| `query.ingress.grpc.secretName`                           | Custom secretName for the ingress resource (GRPC)                                                                                       | `""`                     |
| `query.ingress.grpc.ingressClassName`                     | IngressClass that will be be used to implement the Ingress (Kubernetes 1.18+)                                                           | `""`                     |
| `query.ingress.grpc.annotations`                          | Additional annotations for the Ingress resource (GRPC). To enable certificate autogeneration, place here your cert-manager annotations. | `{}`                     |
| `query.ingress.grpc.extraHosts`                           | The list of additional hostnames to be covered with this ingress record.                                                                | `[]`                     |
| `query.ingress.grpc.extraTls`                             | The tls configuration for additional hostnames to be covered with this ingress record.                                                  | `[]`                     |
| `query.ingress.grpc.secrets`                              | If you're providing your own certificates, please use this to add the certificates as secrets                                           | `[]`                     |
| `query.ingress.grpc.extraRules`                           | Additional rules to be covered with this ingress record                                                                                 | `[]`                     |
| `query.ingress.grpc.tls`                                  | Enable TLS configuration for the hostname defined at `query.ingress.grpc.hostname` parameter                                            | `false`                  |
| `query.ingress.grpc.selfSigned`                           | Create a TLS secret for this ingress record using self-signed certificates generated by Helm                                            | `false`                  |
| `query.ingress.grpc.apiVersion`                           | Override API Version (automatically detected if not set)                                                                                | `""`                     |
| `query.ingress.grpc.path`                                 | Ingress Path                                                                                                                            | `/`                      |
| `query.ingress.grpc.pathType`                             | Ingress Path type                                                                                                                       | `ImplementationSpecific` |

### Thanos Query Frontend parameters

| Name                                                              | Description                                                                                                                      | Value                    |
| ----------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------- | ------------------------ |
| `queryFrontend.enabled`                                           | Enable/disable Thanos Query Frontend component                                                                                   | `true`                   |
| `queryFrontend.logLevel`                                          | Thanos Query Frontend log level                                                                                                  | `info`                   |
| `queryFrontend.logFormat`                                         | Thanos Query Frontend log format                                                                                                 | `logfmt`                 |
| `queryFrontend.config`                                            | Thanos Query Frontend configuration                                                                                              | `""`                     |
| `queryFrontend.existingConfigmap`                                 | Name of existing ConfigMap with Thanos Query Frontend configuration                                                              | `""`                     |
| `queryFrontend.extraEnvVars`                                      | Extra environment variables for Thanos Query Frontend container                                                                  | `[]`                     |
| `queryFrontend.extraEnvVarsCM`                                    | Name of existing ConfigMap containing extra env vars for Thanos Query Frontend nodes                                             | `""`                     |
| `queryFrontend.extraEnvVarsSecret`                                | Name of existing Secret containing extra env vars for Thanos Query Frontend nodes                                                | `""`                     |
| `queryFrontend.extraFlags`                                        | Extra Flags to passed to Thanos Query Frontend                                                                                   | `[]`                     |
| `queryFrontend.command`                                           | Override default container command (useful when using custom images)                                                             | `[]`                     |
| `queryFrontend.args`                                              | Override default container args (useful when using custom images)                                                                | `[]`                     |
| `queryFrontend.replicaCount`                                      | Number of Thanos Query Frontend replicas to deploy                                                                               | `1`                      |
| `queryFrontend.updateStrategy.type`                               | Update strategy type for Thanos Query Frontend replicas                                                                          | `RollingUpdate`          |
| `queryFrontend.podSecurityContext.enabled`                        | Enable security context for the Thanos Query Frontend pods                                                                       | `true`                   |
| `queryFrontend.podSecurityContext.fsGroup`                        | Group ID for the filesystem used by Thanos Query Frontend pods                                                                   | `1001`                   |
| `queryFrontend.containerSecurityContext.enabled`                  | Enabled containers' Security Context                                                                                             | `true`                   |
| `queryFrontend.containerSecurityContext.runAsUser`                | Set containers' Security Context runAsUser                                                                                       | `1001`                   |
| `queryFrontend.containerSecurityContext.runAsNonRoot`             | Set container's Security Context runAsNonRoot                                                                                    | `true`                   |
| `queryFrontend.containerSecurityContext.privileged`               | Set container's Security Context privileged                                                                                      | `false`                  |
| `queryFrontend.containerSecurityContext.readOnlyRootFilesystem`   | Set container's Security Context readOnlyRootFilesystem                                                                          | `true`                   |
| `queryFrontend.containerSecurityContext.allowPrivilegeEscalation` | Set container's Security Context allowPrivilegeEscalation                                                                        | `false`                  |
| `queryFrontend.containerSecurityContext.capabilities.drop`        | List of capabilities to be dropped                                                                                               | `["ALL"]`                |
| `queryFrontend.containerSecurityContext.seccompProfile.type`      | Set container's Security Context seccomp profile                                                                                 | `RuntimeDefault`         |
| `queryFrontend.resources.limits`                                  | The resources limits for the Thanos Query Frontend container                                                                     | `{}`                     |
| `queryFrontend.resources.requests`                                | The requested resources for the Thanos Query Frontend container                                                                  | `{}`                     |
| `queryFrontend.livenessProbe.enabled`                             | Enable livenessProbe on Thanos Query Frontend containers                                                                         | `true`                   |
| `queryFrontend.livenessProbe.initialDelaySeconds`                 | Initial delay seconds for livenessProbe                                                                                          | `30`                     |
| `queryFrontend.livenessProbe.periodSeconds`                       | Period seconds for livenessProbe                                                                                                 | `10`                     |
| `queryFrontend.livenessProbe.timeoutSeconds`                      | Timeout seconds for livenessProbe                                                                                                | `30`                     |
| `queryFrontend.livenessProbe.failureThreshold`                    | Failure threshold for livenessProbe                                                                                              | `6`                      |
| `queryFrontend.livenessProbe.successThreshold`                    | Success threshold for livenessProbe                                                                                              | `1`                      |
| `queryFrontend.readinessProbe.enabled`                            | Enable readinessProbe on Thanos Query Frontend containers                                                                        | `true`                   |
| `queryFrontend.readinessProbe.initialDelaySeconds`                | Initial delay seconds for readinessProbe                                                                                         | `30`                     |
| `queryFrontend.readinessProbe.periodSeconds`                      | Period seconds for readinessProbe                                                                                                | `10`                     |
| `queryFrontend.readinessProbe.timeoutSeconds`                     | Timeout seconds for readinessProbe                                                                                               | `30`                     |
| `queryFrontend.readinessProbe.failureThreshold`                   | Failure threshold for readinessProbe                                                                                             | `6`                      |
| `queryFrontend.readinessProbe.successThreshold`                   | Success threshold for readinessProbe                                                                                             | `1`                      |
| `queryFrontend.startupProbe.enabled`                              | Enable startupProbe on Thanos Query Frontend containers                                                                          | `false`                  |
| `queryFrontend.startupProbe.initialDelaySeconds`                  | Initial delay seconds for startupProbe                                                                                           | `5`                      |
| `queryFrontend.startupProbe.periodSeconds`                        | Period seconds for startupProbe                                                                                                  | `5`                      |
| `queryFrontend.startupProbe.timeoutSeconds`                       | Timeout seconds for startupProbe                                                                                                 | `1`                      |
| `queryFrontend.startupProbe.failureThreshold`                     | Failure threshold for startupProbe                                                                                               | `15`                     |
| `queryFrontend.startupProbe.successThreshold`                     | Success threshold for startupProbe                                                                                               | `1`                      |
| `queryFrontend.customLivenessProbe`                               | Custom livenessProbe that overrides the default one                                                                              | `{}`                     |
| `queryFrontend.customReadinessProbe`                              | Custom readinessProbe that overrides the default one                                                                             | `{}`                     |
| `queryFrontend.customStartupProbe`                                | Custom startupProbe that overrides the default one                                                                               | `{}`                     |
| `queryFrontend.initContainers`                                    | Add additional init containers to the Thanos Query Frontend pods                                                                 | `[]`                     |
| `queryFrontend.sidecars`                                          | Extra containers running as sidecars to Thanos Query Frontend pods                                                               | `[]`                     |
| `queryFrontend.extraVolumes`                                      | Extra volumes to add to Thanos Query Frontend                                                                                    | `[]`                     |
| `queryFrontend.extraVolumeMounts`                                 | Extra volume mounts to add to the query-frontend container                                                                       | `[]`                     |
| `queryFrontend.podAffinityPreset`                                 | Thanos Query Frontend pod affinity preset                                                                                        | `""`                     |
| `queryFrontend.podAntiAffinityPreset`                             | Thanos Query Frontend pod anti-affinity preset. Ignored if `queryFrontend.affinity` is set. Allowed values: `soft` or `hard`     | `soft`                   |
| `queryFrontend.nodeAffinityPreset.type`                           | Thanos Query Frontend node affinity preset type. Ignored if `queryFrontend.affinity` is set. Allowed values: `soft` or `hard`    | `""`                     |
| `queryFrontend.nodeAffinityPreset.key`                            | Thanos Query Frontend node label key to match. Ignored if `queryFrontend.affinity` is set.                                       | `""`                     |
| `queryFrontend.nodeAffinityPreset.values`                         | Thanos Query Frontend node label values to match. Ignored if `queryFrontend.affinity` is set.                                    | `[]`                     |
| `queryFrontend.affinity`                                          | Thanos Query Frontend affinity for pod assignment                                                                                | `{}`                     |
| `queryFrontend.nodeSelector`                                      | Thanos Query Frontend node labels for pod assignment                                                                             | `{}`                     |
| `queryFrontend.tolerations`                                       | Thanos Query Frontend tolerations for pod assignment                                                                             | `[]`                     |
| `queryFrontend.podLabels`                                         | Thanos Query Frontend pod labels                                                                                                 | `{}`                     |
| `queryFrontend.podAnnotations`                                    | Annotations for Thanos Query Frontend pods                                                                                       | `{}`                     |
| `queryFrontend.dnsConfig`                                         | Deployment pod DNS config                                                                                                        | `{}`                     |
| `queryFrontend.dnsPolicy`                                         | Deployment pod DNS policy                                                                                                        | `""`                     |
| `queryFrontend.hostAliases`                                       | Deployment pod host aliases                                                                                                      | `[]`                     |
| `queryFrontend.lifecycleHooks`                                    | for the Thanos Query Frontend container(s) to automate configuration before or after startup                                     | `{}`                     |
| `queryFrontend.priorityClassName`                                 | Thanos Query Frontend priorityClassName                                                                                          | `""`                     |
| `queryFrontend.schedulerName`                                     | Name of the k8s scheduler (other than default) for Thanos Query Frontend pods                                                    | `""`                     |
| `queryFrontend.topologySpreadConstraints`                         | Topology Spread Constraints for Thanos Query Frontend pods assignment spread across your cluster among failure-domains           | `[]`                     |
| `queryFrontend.service.type`                                      | Kubernetes service type                                                                                                          | `ClusterIP`              |
| `queryFrontend.service.ports.http`                                | Thanos Query Frontend service HTTP port                                                                                          | `9090`                   |
| `queryFrontend.service.nodePorts.http`                            | Specify the Thanos Query Frontend HTTP nodePort value for the LoadBalancer and NodePort service types                            | `""`                     |
| `queryFrontend.service.clusterIP`                                 | Thanos Query Frontend service clusterIP IP                                                                                       | `""`                     |
| `queryFrontend.service.loadBalancerIP`                            | Load balancer IP if service type is `LoadBalancer`                                                                               | `""`                     |
| `queryFrontend.service.loadBalancerSourceRanges`                  | Address that are allowed when service is LoadBalancer                                                                            | `[]`                     |
| `queryFrontend.service.externalTrafficPolicy`                     | Thanos Query Frontend service externalTrafficPolicy                                                                              | `Cluster`                |
| `queryFrontend.service.annotations`                               | Annotations for Thanos Query Frontend service                                                                                    | `{}`                     |
| `queryFrontend.service.labels`                                    | Labels for Thanos Query Frontend service                                                                                         | `{}`                     |
| `queryFrontend.service.extraPorts`                                | Extra ports to expose in the Thanos Query Frontend service                                                                       | `[]`                     |
| `queryFrontend.service.labelSelectorsOverride`                    | Selector for Thanos Query service                                                                                                | `{}`                     |
| `queryFrontend.automountServiceAccountToken`                      | Enable/disable auto mounting of the service account token only for the deployment                                                | `true`                   |
| `queryFrontend.serviceAccount.create`                             | Specifies whether a ServiceAccount should be created                                                                             | `true`                   |
| `queryFrontend.serviceAccount.name`                               | Name of the service account to use. If not set and create is true, a name is generated using the fullname template.              | `""`                     |
| `queryFrontend.serviceAccount.annotations`                        | Annotations for Thanos Query Frontend Service Account                                                                            | `{}`                     |
| `queryFrontend.serviceAccount.automountServiceAccountToken`       | Enable/disable auto mounting of the service account token                                                                        | `true`                   |
| `queryFrontend.rbac.create`                                       | Create a ClusterRole and ClusterRoleBinding for the Thanos Query Frontend Service Account                                        | `false`                  |
| `queryFrontend.rbac.rules`                                        | Custom RBAC rules to set                                                                                                         | `[]`                     |
| `queryFrontend.pspEnabled`                                        | Whether to create a PodSecurityPolicy for Thanos Query Frontend                                                                  | `false`                  |
| `queryFrontend.autoscaling.enabled`                               | Enable autoscaling for Thanos Query Frontend                                                                                     | `false`                  |
| `queryFrontend.autoscaling.minReplicas`                           | Minimum number of Thanos Query Frontend replicas                                                                                 | `""`                     |
| `queryFrontend.autoscaling.maxReplicas`                           | Maximum number of Thanos Query Frontend replicas                                                                                 | `""`                     |
| `queryFrontend.autoscaling.targetCPU`                             | Target CPU utilization percentage                                                                                                | `""`                     |
| `queryFrontend.autoscaling.targetMemory`                          | Target Memory utilization percentage                                                                                             | `""`                     |
| `queryFrontend.pdb.create`                                        | Enable/disable a Pod Disruption Budget creation for Thanos Query Frontend                                                        | `false`                  |
| `queryFrontend.pdb.minAvailable`                                  | Minimum number/percentage of pods that should remain scheduled                                                                   | `1`                      |
| `queryFrontend.pdb.maxUnavailable`                                | Maximum number/percentage of pods that may be made unavailable                                                                   | `""`                     |
| `queryFrontend.ingress.enabled`                                   | Enable ingress controller resource                                                                                               | `false`                  |
| `queryFrontend.ingress.hostname`                                  | Default host for the ingress resource                                                                                            | `thanos.local`           |
| `queryFrontend.ingress.overrideAlertQueryURL`                     | Automatically use query-frontend's ingress hostname as --alert.queryURL for both Query and Ruler.                                | `true`                   |
| `queryFrontend.ingress.ingressClassName`                          | IngressClass that will be be used to implement the Ingress (Kubernetes 1.18+)                                                    | `""`                     |
| `queryFrontend.ingress.annotations`                               | Additional annotations for the Ingress resource. To enable certificate autogeneration, place here your cert-manager annotations. | `{}`                     |
| `queryFrontend.ingress.extraHosts`                                | The list of additional hostnames to be covered with this ingress record.                                                         | `[]`                     |
| `queryFrontend.ingress.extraTls`                                  | The tls configuration for additional hostnames to be covered with this ingress record.                                           | `[]`                     |
| `queryFrontend.ingress.secrets`                                   | If you're providing your own certificates, please use this to add the certificates as secrets                                    | `[]`                     |
| `queryFrontend.ingress.extraRules`                                | Additional rules to be covered with this ingress record                                                                          | `[]`                     |
| `queryFrontend.ingress.tls`                                       | Enable TLS configuration for the hostname defined at `queryFrontend.ingress.hostname` parameter                                  | `false`                  |
| `queryFrontend.ingress.selfSigned`                                | Create a TLS secret for this ingress record using self-signed certificates generated by Helm                                     | `false`                  |
| `queryFrontend.ingress.apiVersion`                                | Force Ingress API version (automatically detected if not set)                                                                    | `""`                     |
| `queryFrontend.ingress.path`                                      | Ingress path                                                                                                                     | `/`                      |
| `queryFrontend.ingress.pathType`                                  | Ingress path type                                                                                                                | `ImplementationSpecific` |

### Thanos Bucket Web parameters

| Name                                                          | Description                                                                                                                      | Value                    |
| ------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------- | ------------------------ |
| `bucketweb.enabled`                                           | Enable/disable Thanos Bucket Web component                                                                                       | `false`                  |
| `bucketweb.logLevel`                                          | Thanos Bucket Web log level                                                                                                      | `info`                   |
| `bucketweb.logFormat`                                         | Thanos Bucket Web log format                                                                                                     | `logfmt`                 |
| `bucketweb.refresh`                                           | Refresh interval to download metadata from remote storage                                                                        | `30m`                    |
| `bucketweb.timeout`                                           | Timeout to download metadata from remote storage                                                                                 | `5m`                     |
| `bucketweb.extraEnvVars`                                      | Extra environment variables for Thanos Bucket Web container                                                                      | `[]`                     |
| `bucketweb.extraEnvVarsCM`                                    | Name of existing ConfigMap containing extra env vars for Thanos Bucket Web nodes                                                 | `""`                     |
| `bucketweb.extraEnvVarsSecret`                                | Name of existing Secret containing extra env vars for Thanos Bucket Web nodes                                                    | `""`                     |
| `bucketweb.extraFlags`                                        | Extra Flags to passed to Thanos Bucket Web                                                                                       | `[]`                     |
| `bucketweb.command`                                           | Override default container command (useful when using custom images)                                                             | `[]`                     |
| `bucketweb.args`                                              | Override default container args (useful when using custom images)                                                                | `[]`                     |
| `bucketweb.replicaCount`                                      | Number of Thanos Bucket Web replicas to deploy                                                                                   | `1`                      |
| `bucketweb.updateStrategy.type`                               | Update strategy type for Thanos Bucket Web replicas                                                                              | `RollingUpdate`          |
| `bucketweb.podSecurityContext.enabled`                        | Enable security context for the Thanos Bucket Web pods                                                                           | `true`                   |
| `bucketweb.podSecurityContext.fsGroup`                        | Group ID for the filesystem used by Thanos Bucket Web pods                                                                       | `1001`                   |
| `bucketweb.containerSecurityContext.enabled`                  | Enabled containers' Security Context                                                                                             | `true`                   |
| `bucketweb.containerSecurityContext.runAsUser`                | Set containers' Security Context runAsUser                                                                                       | `1001`                   |
| `bucketweb.containerSecurityContext.runAsNonRoot`             | Set container's Security Context runAsNonRoot                                                                                    | `true`                   |
| `bucketweb.containerSecurityContext.privileged`               | Set container's Security Context privileged                                                                                      | `false`                  |
| `bucketweb.containerSecurityContext.readOnlyRootFilesystem`   | Set container's Security Context readOnlyRootFilesystem                                                                          | `true`                   |
| `bucketweb.containerSecurityContext.allowPrivilegeEscalation` | Set container's Security Context allowPrivilegeEscalation                                                                        | `false`                  |
| `bucketweb.containerSecurityContext.capabilities.drop`        | List of capabilities to be dropped                                                                                               | `["ALL"]`                |
| `bucketweb.containerSecurityContext.seccompProfile.type`      | Set container's Security Context seccomp profile                                                                                 | `RuntimeDefault`         |
| `bucketweb.resources.limits`                                  | The resources limits for the Thanos Bucket Web container                                                                         | `{}`                     |
| `bucketweb.resources.requests`                                | The requested resources for the Thanos Bucket Web container                                                                      | `{}`                     |
| `bucketweb.livenessProbe.enabled`                             | Enable livenessProbe on Thanos Bucket Web containers                                                                             | `true`                   |
| `bucketweb.livenessProbe.initialDelaySeconds`                 | Initial delay seconds for livenessProbe                                                                                          | `30`                     |
| `bucketweb.livenessProbe.periodSeconds`                       | Period seconds for livenessProbe                                                                                                 | `10`                     |
| `bucketweb.livenessProbe.timeoutSeconds`                      | Timeout seconds for livenessProbe                                                                                                | `30`                     |
| `bucketweb.livenessProbe.failureThreshold`                    | Failure threshold for livenessProbe                                                                                              | `6`                      |
| `bucketweb.livenessProbe.successThreshold`                    | Success threshold for livenessProbe                                                                                              | `1`                      |
| `bucketweb.readinessProbe.enabled`                            | Enable readinessProbe on Thanos Bucket Web containers                                                                            | `true`                   |
| `bucketweb.readinessProbe.initialDelaySeconds`                | Initial delay seconds for readinessProbe                                                                                         | `30`                     |
| `bucketweb.readinessProbe.periodSeconds`                      | Period seconds for readinessProbe                                                                                                | `10`                     |
| `bucketweb.readinessProbe.timeoutSeconds`                     | Timeout seconds for readinessProbe                                                                                               | `30`                     |
| `bucketweb.readinessProbe.failureThreshold`                   | Failure threshold for readinessProbe                                                                                             | `6`                      |
| `bucketweb.readinessProbe.successThreshold`                   | Success threshold for readinessProbe                                                                                             | `1`                      |
| `bucketweb.startupProbe.enabled`                              | Enable startupProbe on Thanos Bucket Web containers                                                                              | `false`                  |
| `bucketweb.startupProbe.initialDelaySeconds`                  | Initial delay seconds for startupProbe                                                                                           | `5`                      |
| `bucketweb.startupProbe.periodSeconds`                        | Period seconds for startupProbe                                                                                                  | `5`                      |
| `bucketweb.startupProbe.timeoutSeconds`                       | Timeout seconds for startupProbe                                                                                                 | `1`                      |
| `bucketweb.startupProbe.failureThreshold`                     | Failure threshold for startupProbe                                                                                               | `15`                     |
| `bucketweb.startupProbe.successThreshold`                     | Success threshold for startupProbe                                                                                               | `1`                      |
| `bucketweb.customLivenessProbe`                               | Custom livenessProbe that overrides the default one                                                                              | `{}`                     |
| `bucketweb.customReadinessProbe`                              | Custom readinessProbe that overrides the default one                                                                             | `{}`                     |
| `bucketweb.customStartupProbe`                                | Custom startupProbe that overrides the default one                                                                               | `{}`                     |
| `bucketweb.initContainers`                                    | Add additional init containers to the Thanos Bucket Web pods                                                                     | `[]`                     |
| `bucketweb.sidecars`                                          | Extra containers running as sidecars to Thanos Bucket Web pods                                                                   | `[]`                     |
| `bucketweb.extraVolumes`                                      | Extra volumes to add to Bucket Web                                                                                               | `[]`                     |
| `bucketweb.extraVolumeMounts`                                 | Extra volume mounts to add to the bucketweb container                                                                            | `[]`                     |
| `bucketweb.podAffinityPreset`                                 | Thanos Bucket Web pod affinity preset                                                                                            | `""`                     |
| `bucketweb.podAntiAffinityPreset`                             | Thanos Bucket Web pod anti-affinity preset. Ignored if `bucketweb.affinity` is set. Allowed values: `soft` or `hard`             | `soft`                   |
| `bucketweb.nodeAffinityPreset.type`                           | Thanos Bucket Web node affinity preset type. Ignored if `bucketweb.affinity` is set. Allowed values: `soft` or `hard`            | `""`                     |
| `bucketweb.nodeAffinityPreset.key`                            | Thanos Bucket Web node label key to match. Ignored if `bucketweb.affinity` is set.                                               | `""`                     |
| `bucketweb.nodeAffinityPreset.values`                         | Thanos Bucket Web node label values to match. Ignored if `bucketweb.affinity` is set.                                            | `[]`                     |
| `bucketweb.affinity`                                          | Thanos Bucket Web affinity for pod assignment                                                                                    | `{}`                     |
| `bucketweb.nodeSelector`                                      | Thanos Bucket Web node labels for pod assignment                                                                                 | `{}`                     |
| `bucketweb.tolerations`                                       | Thanos Bucket Web tolerations for pod assignment                                                                                 | `[]`                     |
| `bucketweb.podLabels`                                         | Thanos Bucket Web pod labels                                                                                                     | `{}`                     |
| `bucketweb.podAnnotations`                                    | Annotations for Thanos Bucket Web pods                                                                                           | `{}`                     |
| `bucketweb.dnsConfig`                                         | Deployment pod DNS config                                                                                                        | `{}`                     |
| `bucketweb.dnsPolicy`                                         | Deployment pod DNS policy                                                                                                        | `""`                     |
| `bucketweb.hostAliases`                                       | Deployment pod host aliases                                                                                                      | `[]`                     |
| `bucketweb.lifecycleHooks`                                    | for the Thanos Bucket Web container(s) to automate configuration before or after startup                                         | `{}`                     |
| `bucketweb.priorityClassName`                                 | Thanos Bucket Web priorityClassName                                                                                              | `""`                     |
| `bucketweb.schedulerName`                                     | Name of the k8s scheduler (other than default) for Thanos Bucket Web pods                                                        | `""`                     |
| `bucketweb.topologySpreadConstraints`                         | Topology Spread Constraints for Thanos Bucket Web pods assignment spread across your cluster among failure-domains               | `[]`                     |
| `bucketweb.service.type`                                      | Kubernetes service type                                                                                                          | `ClusterIP`              |
| `bucketweb.service.ports.http`                                | Thanos Bucket Web service HTTP port                                                                                              | `8080`                   |
| `bucketweb.service.nodePorts.http`                            | Specify the Thanos Bucket Web HTTP nodePort value for the LoadBalancer and NodePort service types                                | `""`                     |
| `bucketweb.service.clusterIP`                                 | Thanos Bucket Web service clusterIP IP                                                                                           | `""`                     |
| `bucketweb.service.loadBalancerIP`                            | Load balancer IP if service type is `LoadBalancer`                                                                               | `""`                     |
| `bucketweb.service.loadBalancerSourceRanges`                  | Address that are allowed when service is LoadBalancer                                                                            | `[]`                     |
| `bucketweb.service.externalTrafficPolicy`                     | Thanos Bucket Web service externalTrafficPolicy                                                                                  | `Cluster`                |
| `bucketweb.service.labels`                                    | Extra labels for Thanos Bucket Web service                                                                                       | `{}`                     |
| `bucketweb.service.annotations`                               | Annotations for Thanos Bucket Web service                                                                                        | `{}`                     |
| `bucketweb.service.extraPorts`                                | Extra ports to expose in the Thanos Bucket Web service                                                                           | `[]`                     |
| `bucketweb.service.labelSelectorsOverride`                    | Selector for Thanos Query service                                                                                                | `{}`                     |
| `bucketweb.automountServiceAccountToken`                      | Enable/disable auto mounting of the service account token only for the deployment                                                | `true`                   |
| `bucketweb.serviceAccount.create`                             | Specifies whether a ServiceAccount should be created                                                                             | `true`                   |
| `bucketweb.serviceAccount.name`                               | Name of the service account to use. If not set and create is true, a name is generated using the fullname template.              | `""`                     |
| `bucketweb.serviceAccount.annotations`                        | Annotations for Thanos Bucket Web Service Account                                                                                | `{}`                     |
| `bucketweb.serviceAccount.automountServiceAccountToken`       | Enable/disable auto mounting of the service account token                                                                        | `true`                   |
| `bucketweb.autoscaling.enabled`                               | Enable autoscaling for Thanos Bucket Web                                                                                         | `false`                  |
| `bucketweb.autoscaling.minReplicas`                           | Minimum number of Thanos Bucket Web replicas                                                                                     | `""`                     |
| `bucketweb.autoscaling.maxReplicas`                           | Maximum number of Thanos Bucket Web replicas                                                                                     | `""`                     |
| `bucketweb.autoscaling.targetCPU`                             | Target CPU utilization percentage                                                                                                | `""`                     |
| `bucketweb.autoscaling.targetMemory`                          | Target Memory utilization percentage                                                                                             | `""`                     |
| `bucketweb.pdb.create`                                        | Enable/disable a Pod Disruption Budget creation for Thanos Bucket Web                                                            | `false`                  |
| `bucketweb.pdb.minAvailable`                                  | Minimum number/percentage of pods that should remain scheduled                                                                   | `1`                      |
| `bucketweb.pdb.maxUnavailable`                                | Maximum number/percentage of pods that may be made unavailable                                                                   | `""`                     |
| `bucketweb.ingress.enabled`                                   | Enable ingress controller resource                                                                                               | `false`                  |
| `bucketweb.ingress.hostname`                                  | Default host for the ingress resource                                                                                            | `thanos-bucketweb.local` |
| `bucketweb.ingress.ingressClassName`                          | IngressClass that will be be used to implement the Ingress (Kubernetes 1.18+)                                                    | `""`                     |
| `bucketweb.ingress.annotations`                               | Additional annotations for the Ingress resource. To enable certificate autogeneration, place here your cert-manager annotations. | `{}`                     |
| `bucketweb.ingress.extraHosts`                                | The list of additional hostnames to be covered with this ingress record.                                                         | `[]`                     |
| `bucketweb.ingress.extraTls`                                  | The tls configuration for additional hostnames to be covered with this ingress record.                                           | `[]`                     |
| `bucketweb.ingress.secrets`                                   | If you're providing your own certificates, please use this to add the certificates as secrets                                    | `[]`                     |
| `bucketweb.ingress.extraRules`                                | Additional rules to be covered with this ingress record                                                                          | `[]`                     |
| `bucketweb.ingress.tls`                                       | Enable TLS configuration for the hostname defined at `bucketweb.ingress.hostname` parameter                                      | `false`                  |
| `bucketweb.ingress.selfSigned`                                | Create a TLS secret for this ingress record using self-signed certificates generated by Helm                                     | `false`                  |
| `bucketweb.ingress.apiVersion`                                | Force Ingress API version (automatically detected if not set)                                                                    | `""`                     |
| `bucketweb.ingress.path`                                      | Ingress path                                                                                                                     | `/`                      |
| `bucketweb.ingress.pathType`                                  | Ingress path type                                                                                                                | `ImplementationSpecific` |

### Thanos Compactor parameters

| Name                                                          | Description                                                                                                                      | Value                    |
| ------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------- | ------------------------ |
| `compactor.enabled`                                           | Enable/disable Thanos Compactor component                                                                                        | `false`                  |
| `compactor.logLevel`                                          | Thanos Compactor log level                                                                                                       | `info`                   |
| `compactor.logFormat`                                         | Thanos Compactor log format                                                                                                      | `logfmt`                 |
| `compactor.retentionResolutionRaw`                            | Resolution and Retention flag                                                                                                    | `30d`                    |
| `compactor.retentionResolution5m`                             | Resolution and Retention flag                                                                                                    | `30d`                    |
| `compactor.retentionResolution1h`                             | Resolution and Retention flag                                                                                                    | `10y`                    |
| `compactor.consistencyDelay`                                  | Minimum age of fresh (non-compacted) blocks before they are being processed                                                      | `30m`                    |
| `compactor.extraEnvVars`                                      | Extra environment variables for Thanos Compactor container                                                                       | `[]`                     |
| `compactor.extraEnvVarsCM`                                    | Name of existing ConfigMap containing extra env vars for Thanos Compactor nodes                                                  | `""`                     |
| `compactor.extraEnvVarsSecret`                                | Name of existing Secret containing extra env vars for Thanos Compactor nodes                                                     | `""`                     |
| `compactor.extraFlags`                                        | Extra Flags to passed to Thanos Compactor                                                                                        | `[]`                     |
| `compactor.command`                                           | Override default container command (useful when using custom images)                                                             | `[]`                     |
| `compactor.args`                                              | Override default container args (useful when using custom images)                                                                | `[]`                     |
| `compactor.cronJob.enabled`                                   | Run compactor as a CronJob rather than a Deployment                                                                              | `false`                  |
| `compactor.cronJob.schedule`                                  | The schedule in Cron format, see <https://en.wikipedia.org/wiki/Cron>                                                            | `0 */6 * * *`            |
| `compactor.cronJob.timeZone`                                  | The time zone name for the given schedule, see <https://en.wikipedia.org/wiki/List_of_tz_database_time_zones>                    | `""`                     |
| `compactor.cronJob.concurrencyPolicy`                         | Specifies how to treat concurrent executions of a Job                                                                            | `Forbid`                 |
| `compactor.cronJob.startingDeadlineSeconds`                   | Optional deadline in seconds for starting the job if it misses scheduled time for any reason                                     | `""`                     |
| `compactor.cronJob.suspend`                                   | This flag tells the controller to suspend subsequent executions                                                                  | `""`                     |
| `compactor.cronJob.successfulJobsHistoryLimit`                | The number of successful finished jobs to retain                                                                                 | `""`                     |
| `compactor.cronJob.failedJobsHistoryLimit`                    | The number of failed finished jobs to retain                                                                                     | `""`                     |
| `compactor.cronJob.backoffLimit`                              | The number of retries before marking this job failed                                                                             | `""`                     |
| `compactor.cronJob.ttlSecondsAfterFinished`                   | The maximum retention before removing the job                                                                                    | `""`                     |
| `compactor.restartPolicy`                                     | Compactor container restart policy.                                                                                              | `""`                     |
| `compactor.updateStrategy.type`                               | Update strategy type for Thanos Compactor replicas                                                                               | `Recreate`               |
| `compactor.podSecurityContext.enabled`                        | Enable security context for the Thanos Compactor pods                                                                            | `true`                   |
| `compactor.podSecurityContext.fsGroup`                        | Group ID for the filesystem used by Thanos Compactor pods                                                                        | `1001`                   |
| `compactor.containerSecurityContext.enabled`                  | Enabled containers' Security Context                                                                                             | `true`                   |
| `compactor.containerSecurityContext.runAsUser`                | Set containers' Security Context runAsUser                                                                                       | `1001`                   |
| `compactor.containerSecurityContext.runAsNonRoot`             | Set container's Security Context runAsNonRoot                                                                                    | `true`                   |
| `compactor.containerSecurityContext.privileged`               | Set container's Security Context privileged                                                                                      | `false`                  |
| `compactor.containerSecurityContext.readOnlyRootFilesystem`   | Set container's Security Context readOnlyRootFilesystem                                                                          | `true`                   |
| `compactor.containerSecurityContext.allowPrivilegeEscalation` | Set container's Security Context allowPrivilegeEscalation                                                                        | `false`                  |
| `compactor.containerSecurityContext.capabilities.drop`        | List of capabilities to be dropped                                                                                               | `["ALL"]`                |
| `compactor.containerSecurityContext.seccompProfile.type`      | Set container's Security Context seccomp profile                                                                                 | `RuntimeDefault`         |
| `compactor.resources.limits`                                  | The resources limits for the Thanos Compactor container                                                                          | `{}`                     |
| `compactor.resources.requests`                                | The requested resources for the Thanos Compactor container                                                                       | `{}`                     |
| `compactor.livenessProbe.enabled`                             | Enable livenessProbe on Thanos Compactor containers                                                                              | `true`                   |
| `compactor.livenessProbe.initialDelaySeconds`                 | Initial delay seconds for livenessProbe                                                                                          | `30`                     |
| `compactor.livenessProbe.periodSeconds`                       | Period seconds for livenessProbe                                                                                                 | `10`                     |
| `compactor.livenessProbe.timeoutSeconds`                      | Timeout seconds for livenessProbe                                                                                                | `30`                     |
| `compactor.livenessProbe.failureThreshold`                    | Failure threshold for livenessProbe                                                                                              | `6`                      |
| `compactor.livenessProbe.successThreshold`                    | Success threshold for livenessProbe                                                                                              | `1`                      |
| `compactor.readinessProbe.enabled`                            | Enable readinessProbe on Thanos Compactor containers                                                                             | `true`                   |
| `compactor.readinessProbe.initialDelaySeconds`                | Initial delay seconds for readinessProbe                                                                                         | `30`                     |
| `compactor.readinessProbe.periodSeconds`                      | Period seconds for readinessProbe                                                                                                | `10`                     |
| `compactor.readinessProbe.timeoutSeconds`                     | Timeout seconds for readinessProbe                                                                                               | `30`                     |
| `compactor.readinessProbe.failureThreshold`                   | Failure threshold for readinessProbe                                                                                             | `6`                      |
| `compactor.readinessProbe.successThreshold`                   | Success threshold for readinessProbe                                                                                             | `1`                      |
| `compactor.startupProbe.enabled`                              | Enable startupProbe on Thanos Compactor containers                                                                               | `false`                  |
| `compactor.startupProbe.initialDelaySeconds`                  | Initial delay seconds for startupProbe                                                                                           | `5`                      |
| `compactor.startupProbe.periodSeconds`                        | Period seconds for startupProbe                                                                                                  | `5`                      |
| `compactor.startupProbe.timeoutSeconds`                       | Timeout seconds for startupProbe                                                                                                 | `1`                      |
| `compactor.startupProbe.failureThreshold`                     | Failure threshold for startupProbe                                                                                               | `15`                     |
| `compactor.startupProbe.successThreshold`                     | Success threshold for startupProbe                                                                                               | `1`                      |
| `compactor.customLivenessProbe`                               | Custom livenessProbe that overrides the default one                                                                              | `{}`                     |
| `compactor.customReadinessProbe`                              | Custom readinessProbe that overrides the default one                                                                             | `{}`                     |
| `compactor.customStartupProbe`                                | Custom startupProbe that overrides the default one                                                                               | `{}`                     |
| `compactor.initContainers`                                    | Add additional init containers to the Thanos Compactor pods                                                                      | `[]`                     |
| `compactor.sidecars`                                          | Extra containers running as sidecars to Thanos Compactor pods                                                                    | `[]`                     |
| `compactor.extraVolumes`                                      | Extra volumes to add to Thanos Compactor                                                                                         | `[]`                     |
| `compactor.extraVolumeMounts`                                 | Extra volume mounts to add to the compactor container                                                                            | `[]`                     |
| `compactor.podAffinityPreset`                                 | Thanos Compactor pod affinity preset                                                                                             | `""`                     |
| `compactor.podAntiAffinityPreset`                             | Thanos Compactor pod anti-affinity preset. Ignored if `compactor.affinity` is set. Allowed values: `soft` or `hard`              | `soft`                   |
| `compactor.nodeAffinityPreset.type`                           | Thanos Compactor node affinity preset type. Ignored if `compactor.affinity` is set. Allowed values: `soft` or `hard`             | `""`                     |
| `compactor.nodeAffinityPreset.key`                            | Thanos Compactor node label key to match. Ignored if `compactor.affinity` is set.                                                | `""`                     |
| `compactor.nodeAffinityPreset.values`                         | Thanos Compactor node label values to match. Ignored if `compactor.affinity` is set.                                             | `[]`                     |
| `compactor.affinity`                                          | Thanos Compactor affinity for pod assignment                                                                                     | `{}`                     |
| `compactor.nodeSelector`                                      | Thanos Compactor node labels for pod assignment                                                                                  | `{}`                     |
| `compactor.tolerations`                                       | Thanos Compactor tolerations for pod assignment                                                                                  | `[]`                     |
| `compactor.podLabels`                                         | Thanos Compactor pod labels                                                                                                      | `{}`                     |
| `compactor.podAnnotations`                                    | Annotations for Thanos Compactor pods                                                                                            | `{}`                     |
| `compactor.dnsConfig`                                         | Deployment pod DNS config                                                                                                        | `{}`                     |
| `compactor.dnsPolicy`                                         | Deployment pod DNS policy                                                                                                        | `""`                     |
| `compactor.hostAliases`                                       | Deployment pod host aliases                                                                                                      | `[]`                     |
| `compactor.lifecycleHooks`                                    | for the Thanos Compactor container(s) to automate configuration before or after startup                                          | `{}`                     |
| `compactor.priorityClassName`                                 | Thanos Compactor priorityClassName                                                                                               | `""`                     |
| `compactor.schedulerName`                                     | Name of the k8s scheduler (other than default) for Thanos Compactor pods                                                         | `""`                     |
| `compactor.topologySpreadConstraints`                         | Topology Spread Constraints for Thanos Compactor pods assignment spread across your cluster among failure-domains                | `[]`                     |
| `compactor.service.type`                                      | Kubernetes service type                                                                                                          | `ClusterIP`              |
| `compactor.service.ports.http`                                | Thanos Compactor service HTTP port                                                                                               | `9090`                   |
| `compactor.service.nodePorts.http`                            | Specify the Thanos Compactor HTTP nodePort value for the LoadBalancer and NodePort service types                                 | `""`                     |
| `compactor.service.clusterIP`                                 | Thanos Compactor service clusterIP IP                                                                                            | `""`                     |
| `compactor.service.loadBalancerIP`                            | Load balancer IP if service type is `LoadBalancer`                                                                               | `""`                     |
| `compactor.service.loadBalancerSourceRanges`                  | Addresses that are allowed when service is LoadBalancer                                                                          | `[]`                     |
| `compactor.service.externalTrafficPolicy`                     | Thanos Compactor service externalTrafficPolicy                                                                                   | `Cluster`                |
| `compactor.service.labels`                                    | Labels for Thanos Compactor service                                                                                              | `{}`                     |
| `compactor.service.annotations`                               | Annotations for Thanos Compactor service                                                                                         | `{}`                     |
| `compactor.service.extraPorts`                                | Extra ports to expose in the Thanos Compactor service                                                                            | `[]`                     |
| `compactor.service.labelSelectorsOverride`                    | Selector for Thanos Query service                                                                                                | `{}`                     |
| `compactor.automountServiceAccountToken`                      | Enable/disable auto mounting of the service account token only for the deployment                                                | `true`                   |
| `compactor.serviceAccount.create`                             | Specifies whether a ServiceAccount should be created                                                                             | `true`                   |
| `compactor.serviceAccount.name`                               | Name of the service account to use. If not set and create is true, a name is generated using the fullname template.              | `""`                     |
| `compactor.serviceAccount.annotations`                        | Annotations for Thanos Compactor Service Account                                                                                 | `{}`                     |
| `compactor.serviceAccount.automountServiceAccountToken`       | Enable/disable auto mounting of the service account token                                                                        | `true`                   |
| `compactor.ingress.enabled`                                   | Enable ingress controller resource                                                                                               | `false`                  |
| `compactor.ingress.hostname`                                  | Default host for the ingress resource                                                                                            | `thanos-compactor.local` |
| `compactor.ingress.ingressClassName`                          | IngressClass that will be be used to implement the Ingress (Kubernetes 1.18+)                                                    | `""`                     |
| `compactor.ingress.annotations`                               | Additional annotations for the Ingress resource. To enable certificate autogeneration, place here your cert-manager annotations. | `{}`                     |
| `compactor.ingress.extraHosts`                                | The list of additional hostnames to be covered with this ingress record.                                                         | `[]`                     |
| `compactor.ingress.extraTls`                                  | The tls configuration for additional hostnames to be covered with this ingress record.                                           | `[]`                     |
| `compactor.ingress.secrets`                                   | If you're providing your own certificates, please use this to add the certificates as secrets                                    | `[]`                     |
| `compactor.ingress.extraRules`                                | Additional rules to be covered with this ingress record                                                                          | `[]`                     |
| `compactor.ingress.tls`                                       | Enable TLS configuration for the hostname defined at `compactor.ingress.hostname` parameter                                      | `false`                  |
| `compactor.ingress.selfSigned`                                | Create a TLS secret for this ingress record using self-signed certificates generated by Helm                                     | `false`                  |
| `compactor.ingress.apiVersion`                                | Force Ingress API version (automatically detected if not set)                                                                    | `""`                     |
| `compactor.ingress.path`                                      | Ingress path                                                                                                                     | `/`                      |
| `compactor.ingress.pathType`                                  | Ingress path type                                                                                                                | `ImplementationSpecific` |
| `compactor.persistence.enabled`                               | Enable data persistence using PVC(s) on Thanos Compactor pods                                                                    | `true`                   |
| `compactor.persistence.defaultEmptyDir`                       | Defaults to emptyDir if persistence is disabled.                                                                                 | `true`                   |
| `compactor.persistence.storageClass`                          | Specify the `storageClass` used to provision the volume                                                                          | `""`                     |
| `compactor.persistence.accessModes`                           | PVC Access Modes for data volume                                                                                                 | `["ReadWriteOnce"]`      |
| `compactor.persistence.size`                                  | PVC Storage Request for data volume                                                                                              | `8Gi`                    |
| `compactor.persistence.labels`                                | Labels for the PVC                                                                                                               | `{}`                     |
| `compactor.persistence.annotations`                           | Annotations for the PVC                                                                                                          | `{}`                     |
| `compactor.persistence.existingClaim`                         | Name of an existing PVC to use                                                                                                   | `""`                     |

### Thanos Store Gateway parameters

| Name                                                             | Description                                                                                                                              | Value                       |
| ---------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------- | --------------------------- |
| `storegateway.enabled`                                           | Enable/disable Thanos Store Gateway component                                                                                            | `false`                     |
| `storegateway.logLevel`                                          | Thanos Store Gateway log level                                                                                                           | `info`                      |
| `storegateway.logFormat`                                         | Thanos Store Gateway log format                                                                                                          | `logfmt`                    |
| `storegateway.config`                                            | Thanos Store Gateway configuration                                                                                                       | `""`                        |
| `storegateway.existingConfigmap`                                 | Name of existing ConfigMap with Thanos Store Gateway configuration                                                                       | `""`                        |
| `storegateway.grpc.server.tls.enabled`                           | Enable TLS encryption in the GRPC server                                                                                                 | `false`                     |
| `storegateway.grpc.server.tls.autoGenerated`                     | Create self-signed TLS certificates. Currently only supports PEM certificates                                                            | `false`                     |
| `storegateway.grpc.server.tls.cert`                              | TLS Certificate for GRPC server - ignored if existingSecret is provided                                                                  | `""`                        |
| `storegateway.grpc.server.tls.key`                               | TLS Key for GRPC server - ignored if existingSecret is provided                                                                          | `""`                        |
| `storegateway.grpc.server.tls.ca`                                | TLS CA to verify clients against - ignored if existingSecret is provided                                                                 | `""`                        |
| `storegateway.grpc.server.tls.existingSecret`                    | Existing secret containing your own TLS certificates                                                                                     | `{}`                        |
| `storegateway.extraEnvVars`                                      | Extra environment variables for Thanos Store Gateway container                                                                           | `[]`                        |
| `storegateway.extraEnvVarsCM`                                    | Name of existing ConfigMap containing extra env vars for Thanos Store Gateway nodes                                                      | `""`                        |
| `storegateway.extraEnvVarsSecret`                                | Name of existing Secret containing extra env vars for Thanos Store Gateway nodes                                                         | `""`                        |
| `storegateway.extraFlags`                                        | Extra Flags to passed to Thanos Store Gateway                                                                                            | `[]`                        |
| `storegateway.command`                                           | Override default container command (useful when using custom images)                                                                     | `[]`                        |
| `storegateway.args`                                              | Override default container args (useful when using custom images)                                                                        | `[]`                        |
| `storegateway.replicaCount`                                      | Number of Thanos Store Gateway replicas to deploy                                                                                        | `1`                         |
| `storegateway.updateStrategy.type`                               | Update strategy type for Thanos Store Gateway replicas                                                                                   | `RollingUpdate`             |
| `storegateway.podManagementPolicy`                               | Statefulset Pod management policy: OrderedReady (default) or Parallel                                                                    | `OrderedReady`              |
| `storegateway.podSecurityContext.enabled`                        | Enable security context for the Thanos Store Gateway pods                                                                                | `true`                      |
| `storegateway.podSecurityContext.fsGroup`                        | Group ID for the filesystem used by Thanos Store Gateway pods                                                                            | `1001`                      |
| `storegateway.containerSecurityContext.enabled`                  | Enabled containers' Security Context                                                                                                     | `true`                      |
| `storegateway.containerSecurityContext.runAsUser`                | Set containers' Security Context runAsUser                                                                                               | `1001`                      |
| `storegateway.containerSecurityContext.runAsNonRoot`             | Set container's Security Context runAsNonRoot                                                                                            | `true`                      |
| `storegateway.containerSecurityContext.privileged`               | Set container's Security Context privileged                                                                                              | `false`                     |
| `storegateway.containerSecurityContext.readOnlyRootFilesystem`   | Set container's Security Context readOnlyRootFilesystem                                                                                  | `true`                      |
| `storegateway.containerSecurityContext.allowPrivilegeEscalation` | Set container's Security Context allowPrivilegeEscalation                                                                                | `false`                     |
| `storegateway.containerSecurityContext.capabilities.drop`        | List of capabilities to be dropped                                                                                                       | `["ALL"]`                   |
| `storegateway.containerSecurityContext.seccompProfile.type`      | Set container's Security Context seccomp profile                                                                                         | `RuntimeDefault`            |
| `storegateway.resources.limits`                                  | The resources limits for the Thanos Store Gateway container                                                                              | `{}`                        |
| `storegateway.resources.requests`                                | The requested resources for the Thanos Store Gateway container                                                                           | `{}`                        |
| `storegateway.livenessProbe.enabled`                             | Enable livenessProbe on Thanos Store Gateway containers                                                                                  | `true`                      |
| `storegateway.livenessProbe.initialDelaySeconds`                 | Initial delay seconds for livenessProbe                                                                                                  | `30`                        |
| `storegateway.livenessProbe.periodSeconds`                       | Period seconds for livenessProbe                                                                                                         | `10`                        |
| `storegateway.livenessProbe.timeoutSeconds`                      | Timeout seconds for livenessProbe                                                                                                        | `30`                        |
| `storegateway.livenessProbe.failureThreshold`                    | Failure threshold for livenessProbe                                                                                                      | `6`                         |
| `storegateway.livenessProbe.successThreshold`                    | Success threshold for livenessProbe                                                                                                      | `1`                         |
| `storegateway.readinessProbe.enabled`                            | Enable readinessProbe on Thanos Store Gateway containers                                                                                 | `true`                      |
| `storegateway.readinessProbe.initialDelaySeconds`                | Initial delay seconds for readinessProbe                                                                                                 | `30`                        |
| `storegateway.readinessProbe.periodSeconds`                      | Period seconds for readinessProbe                                                                                                        | `10`                        |
| `storegateway.readinessProbe.timeoutSeconds`                     | Timeout seconds for readinessProbe                                                                                                       | `30`                        |
| `storegateway.readinessProbe.failureThreshold`                   | Failure threshold for readinessProbe                                                                                                     | `6`                         |
| `storegateway.readinessProbe.successThreshold`                   | Success threshold for readinessProbe                                                                                                     | `1`                         |
| `storegateway.startupProbe.enabled`                              | Enable startupProbe on Thanos Store Gateway containers                                                                                   | `false`                     |
| `storegateway.startupProbe.initialDelaySeconds`                  | Initial delay seconds for startupProbe                                                                                                   | `5`                         |
| `storegateway.startupProbe.periodSeconds`                        | Period seconds for startupProbe                                                                                                          | `5`                         |
| `storegateway.startupProbe.timeoutSeconds`                       | Timeout seconds for startupProbe                                                                                                         | `1`                         |
| `storegateway.startupProbe.failureThreshold`                     | Failure threshold for startupProbe                                                                                                       | `15`                        |
| `storegateway.startupProbe.successThreshold`                     | Success threshold for startupProbe                                                                                                       | `1`                         |
| `storegateway.customLivenessProbe`                               | Custom livenessProbe that overrides the default one                                                                                      | `{}`                        |
| `storegateway.customReadinessProbe`                              | Custom readinessProbe that overrides the default one                                                                                     | `{}`                        |
| `storegateway.customStartupProbe`                                | Custom startupProbe that overrides the default one                                                                                       | `{}`                        |
| `storegateway.initContainers`                                    | Add additional init containers to the Thanos Store Gateway pods                                                                          | `[]`                        |
| `storegateway.sidecars`                                          | Extra containers running as sidecars to Thanos Store Gateway pods                                                                        | `[]`                        |
| `storegateway.extraVolumes`                                      | Extra volumes to add to Thanos Store Gateway                                                                                             | `[]`                        |
| `storegateway.extraVolumeMounts`                                 | Extra volume mounts to add to the storegateway container                                                                                 | `[]`                        |
| `storegateway.podAffinityPreset`                                 | Thanos Store Gateway pod affinity preset                                                                                                 | `""`                        |
| `storegateway.podAntiAffinityPreset`                             | Thanos Store Gateway pod anti-affinity preset. Ignored if `storegateway.affinity` is set. Allowed values: `soft` or `hard`               | `soft`                      |
| `storegateway.nodeAffinityPreset.type`                           | Thanos Store Gateway node affinity preset type. Ignored if `storegateway.affinity` is set. Allowed values: `soft` or `hard`              | `""`                        |
| `storegateway.nodeAffinityPreset.key`                            | Thanos Store Gateway node label key to match. Ignored if `storegateway.affinity` is set.                                                 | `""`                        |
| `storegateway.nodeAffinityPreset.values`                         | Thanos Store Gateway node label values to match. Ignored if `storegateway.affinity` is set.                                              | `[]`                        |
| `storegateway.affinity`                                          | Thanos Store Gateway affinity for pod assignment                                                                                         | `{}`                        |
| `storegateway.nodeSelector`                                      | Thanos Store Gateway node labels for pod assignment                                                                                      | `{}`                        |
| `storegateway.tolerations`                                       | Thanos Store Gateway tolerations for pod assignment                                                                                      | `[]`                        |
| `storegateway.podLabels`                                         | Thanos Store Gateway pod labels                                                                                                          | `{}`                        |
| `storegateway.podAnnotations`                                    | Annotations for Thanos Store Gateway pods                                                                                                | `{}`                        |
| `storegateway.dnsConfig`                                         | Deployment pod DNS config                                                                                                                | `{}`                        |
| `storegateway.dnsPolicy`                                         | Deployment pod DNS policy                                                                                                                | `""`                        |
| `storegateway.hostAliases`                                       | Deployment pod host aliases                                                                                                              | `[]`                        |
| `storegateway.lifecycleHooks`                                    | for the Thanos Store Gateway container(s) to automate configuration before or after startup                                              | `{}`                        |
| `storegateway.priorityClassName`                                 | Thanos Store Gateway priorityClassName                                                                                                   | `""`                        |
| `storegateway.topologySpreadConstraints`                         | Topology Spread Constraints for Thanos Store Gateway pods assignment spread across your cluster among failure-domains                    | `[]`                        |
| `storegateway.schedulerName`                                     | Name of the k8s scheduler (other than default) for Thanos Store Gateway pods                                                             | `""`                        |
| `storegateway.service.type`                                      | Kubernetes service type                                                                                                                  | `ClusterIP`                 |
| `storegateway.service.ports.http`                                | Thanos Store Gateway service HTTP port                                                                                                   | `9090`                      |
| `storegateway.service.ports.grpc`                                | Thanos Store Gateway service GRPC port                                                                                                   | `10901`                     |
| `storegateway.service.nodePorts.http`                            | Specify the Thanos Store Gateway HTTP nodePort value for the LoadBalancer and NodePort service types                                     | `""`                        |
| `storegateway.service.nodePorts.grpc`                            | Specify the Thanos Store Gateway GRPC nodePort value for the LoadBalancer and NodePort service types                                     | `""`                        |
| `storegateway.service.clusterIP`                                 | Thanos Store Gateway service clusterIP IP                                                                                                | `""`                        |
| `storegateway.service.loadBalancerIP`                            | Load balancer IP if service type is `LoadBalancer`                                                                                       | `""`                        |
| `storegateway.service.loadBalancerSourceRanges`                  | Addresses that are allowed when service is LoadBalancer                                                                                  | `[]`                        |
| `storegateway.service.externalTrafficPolicy`                     | Thanos Store Gateway service externalTrafficPolicy                                                                                       | `Cluster`                   |
| `storegateway.service.labels`                                    | Extra labels for Thanos Store Gateway service                                                                                            | `{}`                        |
| `storegateway.service.annotations`                               | Annotations for Thanos Store Gateway service                                                                                             | `{}`                        |
| `storegateway.service.extraPorts`                                | Extra ports to expose in the Thanos Store Gateway service                                                                                | `[]`                        |
| `storegateway.service.labelSelectorsOverride`                    | Selector for Thanos Query service                                                                                                        | `{}`                        |
| `storegateway.service.additionalHeadless`                        | Additional Headless service                                                                                                              | `false`                     |
| `storegateway.service.headless.annotations`                      | Annotations for the headless service.                                                                                                    | `{}`                        |
| `storegateway.persistence.enabled`                               | Enable data persistence using PVC(s) on Thanos Store Gateway pods                                                                        | `true`                      |
| `storegateway.persistence.storageClass`                          | Specify the `storageClass` used to provision the volume                                                                                  | `""`                        |
| `storegateway.persistence.accessModes`                           | PVC Access Modes for data volume                                                                                                         | `["ReadWriteOnce"]`         |
| `storegateway.persistence.size`                                  | PVC Storage Request for data volume                                                                                                      | `8Gi`                       |
| `storegateway.persistence.labels`                                | Labels for the PVC                                                                                                                       | `{}`                        |
| `storegateway.persistence.annotations`                           | Annotations for the PVC                                                                                                                  | `{}`                        |
| `storegateway.persistence.existingClaim`                         | Name of an existing PVC to use                                                                                                           | `""`                        |
| `storegateway.automountServiceAccountToken`                      | Enable/disable auto mounting of the service account token only for the sts                                                               | `true`                      |
| `storegateway.serviceAccount.create`                             | Specifies whether a ServiceAccount should be created                                                                                     | `true`                      |
| `storegateway.serviceAccount.name`                               | Name of the service account to use. If not set and create is true, a name is generated using the fullname template.                      | `""`                        |
| `storegateway.serviceAccount.annotations`                        | Annotations for Thanos Store Gateway Service Account                                                                                     | `{}`                        |
| `storegateway.serviceAccount.automountServiceAccountToken`       | Enable/disable auto mounting of the service account token                                                                                | `true`                      |
| `storegateway.autoscaling.enabled`                               | Enable autoscaling for Thanos Store Gateway                                                                                              | `false`                     |
| `storegateway.autoscaling.minReplicas`                           | Minimum number of Thanos Store Gateway replicas                                                                                          | `""`                        |
| `storegateway.autoscaling.maxReplicas`                           | Maximum number of Thanos Store Gateway replicas                                                                                          | `""`                        |
| `storegateway.autoscaling.targetCPU`                             | Target CPU utilization percentage                                                                                                        | `""`                        |
| `storegateway.autoscaling.targetMemory`                          | Target Memory utilization percentage                                                                                                     | `""`                        |
| `storegateway.pdb.create`                                        | Enable/disable a Pod Disruption Budget creation for Thanos Store Gateway                                                                 | `false`                     |
| `storegateway.pdb.minAvailable`                                  | Minimum number/percentage of pods that should remain scheduled                                                                           | `1`                         |
| `storegateway.pdb.maxUnavailable`                                | Maximum number/percentage of pods that may be made unavailable                                                                           | `""`                        |
| `storegateway.ingress.enabled`                                   | Enable ingress controller resource                                                                                                       | `false`                     |
| `storegateway.ingress.hostname`                                  | Default host for the ingress resource                                                                                                    | `thanos-storegateway.local` |
| `storegateway.ingress.ingressClassName`                          | IngressClass that will be be used to implement the Ingress (Kubernetes 1.18+)                                                            | `""`                        |
| `storegateway.ingress.annotations`                               | Additional annotations for the Ingress resource. To enable certificate autogeneration, place here your cert-manager annotations.         | `{}`                        |
| `storegateway.ingress.extraHosts`                                | The list of additional hostnames to be covered with this ingress record.                                                                 | `[]`                        |
| `storegateway.ingress.extraTls`                                  | The tls configuration for additional hostnames to be covered with this ingress record.                                                   | `[]`                        |
| `storegateway.ingress.secrets`                                   | If you're providing your own certificates, please use this to add the certificates as secrets                                            | `[]`                        |
| `storegateway.ingress.extraRules`                                | Additional rules to be covered with this ingress record                                                                                  | `[]`                        |
| `storegateway.ingress.tls`                                       | Enable TLS configuration for the hostname defined at `storegateway.ingress.hostname` parameter                                           | `false`                     |
| `storegateway.ingress.selfSigned`                                | Create a TLS secret for this ingress record using self-signed certificates generated by Helm                                             | `false`                     |
| `storegateway.ingress.apiVersion`                                | Force Ingress API version (automatically detected if not set)                                                                            | `""`                        |
| `storegateway.ingress.path`                                      | Ingress path                                                                                                                             | `/`                         |
| `storegateway.ingress.pathType`                                  | Ingress path type                                                                                                                        | `ImplementationSpecific`    |
| `storegateway.ingress.grpc.enabled`                              | Enable ingress controller resource (GRPC)                                                                                                | `false`                     |
| `storegateway.ingress.grpc.hostname`                             | Default host for the ingress resource (GRPC)                                                                                             | `thanos-grpc.local`         |
| `storegateway.ingress.grpc.ingressClassName`                     | IngressClass that will be be used to implement the Ingress (Kubernetes 1.18+)                                                            | `""`                        |
| `storegateway.ingress.grpc.annotations`                          | Additional annotations for the Ingress resource (GRPC). To enable certificate autogeneration, place here your cert-manager annotations.  | `{}`                        |
| `storegateway.ingress.grpc.extraHosts`                           | The list of additional hostnames to be covered with this ingress record.                                                                 | `[]`                        |
| `storegateway.ingress.grpc.extraTls`                             | The tls configuration for additional hostnames to be covered with this ingress record.                                                   | `[]`                        |
| `storegateway.ingress.grpc.secrets`                              | If you're providing your own certificates, please use this to add the certificates as secrets                                            | `[]`                        |
| `storegateway.ingress.grpc.extraRules`                           | Additional rules to be covered with this ingress record                                                                                  | `[]`                        |
| `storegateway.ingress.grpc.tls`                                  | Enable TLS configuration for the hostname defined at `storegateway.ingress.grpc.hostname` parameter                                      | `false`                     |
| `storegateway.ingress.grpc.selfSigned`                           | Create a TLS secret for this ingress record using self-signed certificates generated by Helm                                             | `false`                     |
| `storegateway.ingress.grpc.apiVersion`                           | Override API Version (automatically detected if not set)                                                                                 | `""`                        |
| `storegateway.ingress.grpc.path`                                 | Ingress Path                                                                                                                             | `/`                         |
| `storegateway.ingress.grpc.pathType`                             | Ingress Path type                                                                                                                        | `ImplementationSpecific`    |
| `storegateway.sharded.enabled`                                   | Enable sharding for Thanos Store Gateway                                                                                                 | `false`                     |
| `storegateway.sharded.hashPartitioning.shards`                   | Setting hashPartitioning will create multiple store statefulsets based on the number of shards specified using the hashmod of the blocks | `""`                        |
| `storegateway.sharded.timePartitioning`                          | Setting time timePartitioning will create multiple store deployments based on the number of partitions                                   | `[]`                        |
| `storegateway.sharded.service.clusterIPs`                        | Array of cluster IPs for each Store Gateway service. Length must be the same as the number of shards                                     | `[]`                        |
| `storegateway.sharded.service.loadBalancerIPs`                   | Array of load balancer IPs for each Store Gateway service. Length must be the same as the number of shards                               | `[]`                        |
| `storegateway.sharded.service.http.nodePorts`                    | Array of http node ports used for Store Gateway service. Length must be the same as the number of shards                                 | `[]`                        |
| `storegateway.sharded.service.grpc.nodePorts`                    | Array of grpc node ports used for Store Gateway service. Length must be the same as the number of shards                                 | `[]`                        |

### Thanos Ruler parameters

| Name                                                      | Description                                                                                                                      | Value                    |
| --------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------- | ------------------------ |
| `ruler.enabled`                                           | Enable/disable Thanos Ruler component                                                                                            | `false`                  |
| `ruler.logLevel`                                          | Thanos Ruler log level                                                                                                           | `info`                   |
| `ruler.logFormat`                                         | Thanos Ruler log format                                                                                                          | `logfmt`                 |
| `ruler.replicaLabel`                                      | Label to treat as a replica indicator along which data is de-duplicated                                                          | `replica`                |
| `ruler.dnsDiscovery.enabled`                              | Dynamically configure Query APIs using DNS discovery                                                                             | `true`                   |
| `ruler.queryURL`                                          | Thanos query/query-frontend URL to link in Ruler UI.                                                                             | `""`                     |
| `ruler.alertmanagers`                                     | Alert managers URLs array                                                                                                        | `[]`                     |
| `ruler.alertmanagersConfig`                               | Alert managers configuration                                                                                                     | `""`                     |
| `ruler.evalInterval`                                      | The default evaluation interval to use                                                                                           | `1m`                     |
| `ruler.clusterName`                                       | Used to set the 'ruler_cluster' label                                                                                            | `""`                     |
| `ruler.config`                                            | Ruler configuration                                                                                                              | `""`                     |
| `ruler.existingConfigmap`                                 | Name of existing ConfigMap with Ruler configuration                                                                              | `""`                     |
| `ruler.extraEnvVars`                                      | Extra environment variables for Thanos Ruler container                                                                           | `[]`                     |
| `ruler.extraEnvVarsCM`                                    | Name of existing ConfigMap containing extra env vars for Thanos Ruler nodes                                                      | `""`                     |
| `ruler.extraEnvVarsSecret`                                | Name of existing Secret containing extra env vars for Thanos Ruler nodes                                                         | `""`                     |
| `ruler.extraFlags`                                        | Extra Flags to passed to Thanos Ruler                                                                                            | `[]`                     |
| `ruler.command`                                           | Override default container command (useful when using custom images)                                                             | `[]`                     |
| `ruler.args`                                              | Override default container args (useful when using custom images)                                                                | `[]`                     |
| `ruler.replicaCount`                                      | Number of Thanos Ruler replicas to deploy                                                                                        | `1`                      |
| `ruler.updateStrategy.type`                               | Update strategy type for Thanos Ruler replicas                                                                                   | `RollingUpdate`          |
| `ruler.podManagementPolicy`                               | Statefulset Pod Management Policy Type                                                                                           | `OrderedReady`           |
| `ruler.podSecurityContext.enabled`                        | Enable security context for the Thanos Ruler pods                                                                                | `true`                   |
| `ruler.podSecurityContext.fsGroup`                        | Group ID for the filesystem used by Thanos Ruler pods                                                                            | `1001`                   |
| `ruler.containerSecurityContext.enabled`                  | Enabled containers' Security Context                                                                                             | `true`                   |
| `ruler.containerSecurityContext.runAsUser`                | Set containers' Security Context runAsUser                                                                                       | `1001`                   |
| `ruler.containerSecurityContext.runAsNonRoot`             | Set container's Security Context runAsNonRoot                                                                                    | `true`                   |
| `ruler.containerSecurityContext.privileged`               | Set container's Security Context privileged                                                                                      | `false`                  |
| `ruler.containerSecurityContext.readOnlyRootFilesystem`   | Set container's Security Context readOnlyRootFilesystem                                                                          | `true`                   |
| `ruler.containerSecurityContext.allowPrivilegeEscalation` | Set container's Security Context allowPrivilegeEscalation                                                                        | `false`                  |
| `ruler.containerSecurityContext.capabilities.drop`        | List of capabilities to be dropped                                                                                               | `["ALL"]`                |
| `ruler.containerSecurityContext.seccompProfile.type`      | Set container's Security Context seccomp profile                                                                                 | `RuntimeDefault`         |
| `ruler.resources.limits`                                  | The resources limits for the Thanos Ruler container                                                                              | `{}`                     |
| `ruler.resources.requests`                                | The requested resources for the Thanos Ruler container                                                                           | `{}`                     |
| `ruler.livenessProbe.enabled`                             | Enable livenessProbe on Thanos Ruler containers                                                                                  | `true`                   |
| `ruler.livenessProbe.initialDelaySeconds`                 | Initial delay seconds for livenessProbe                                                                                          | `30`                     |
| `ruler.livenessProbe.periodSeconds`                       | Period seconds for livenessProbe                                                                                                 | `10`                     |
| `ruler.livenessProbe.timeoutSeconds`                      | Timeout seconds for livenessProbe                                                                                                | `30`                     |
| `ruler.livenessProbe.failureThreshold`                    | Failure threshold for livenessProbe                                                                                              | `6`                      |
| `ruler.livenessProbe.successThreshold`                    | Success threshold for livenessProbe                                                                                              | `1`                      |
| `ruler.readinessProbe.enabled`                            | Enable readinessProbe on Thanos Ruler containers                                                                                 | `true`                   |
| `ruler.readinessProbe.initialDelaySeconds`                | Initial delay seconds for readinessProbe                                                                                         | `30`                     |
| `ruler.readinessProbe.periodSeconds`                      | Period seconds for readinessProbe                                                                                                | `10`                     |
| `ruler.readinessProbe.timeoutSeconds`                     | Timeout seconds for readinessProbe                                                                                               | `30`                     |
| `ruler.readinessProbe.failureThreshold`                   | Failure threshold for readinessProbe                                                                                             | `6`                      |
| `ruler.readinessProbe.successThreshold`                   | Success threshold for readinessProbe                                                                                             | `1`                      |
| `ruler.startupProbe.enabled`                              | Enable startupProbe on Thanos Ruler containers                                                                                   | `false`                  |
| `ruler.startupProbe.initialDelaySeconds`                  | Initial delay seconds for startupProbe                                                                                           | `5`                      |
| `ruler.startupProbe.periodSeconds`                        | Period seconds for startupProbe                                                                                                  | `5`                      |
| `ruler.startupProbe.timeoutSeconds`                       | Timeout seconds for startupProbe                                                                                                 | `1`                      |
| `ruler.startupProbe.failureThreshold`                     | Failure threshold for startupProbe                                                                                               | `15`                     |
| `ruler.startupProbe.successThreshold`                     | Success threshold for startupProbe                                                                                               | `1`                      |
| `ruler.customLivenessProbe`                               | Custom livenessProbe that overrides the default one                                                                              | `{}`                     |
| `ruler.customReadinessProbe`                              | Custom readinessProbe that overrides the default one                                                                             | `{}`                     |
| `ruler.customStartupProbe`                                | Custom startupProbe that overrides the default one                                                                               | `{}`                     |
| `ruler.initContainers`                                    | Add additional init containers to the Thanos Ruler pods                                                                          | `[]`                     |
| `ruler.sidecars`                                          | Extra containers running as sidecars to Thanos Ruler pods                                                                        | `[]`                     |
| `ruler.extraVolumes`                                      | Extra volumes to add to Thanos Ruler                                                                                             | `[]`                     |
| `ruler.extraVolumeMounts`                                 | Extra volume mounts to add to the ruler container                                                                                | `[]`                     |
| `ruler.podAffinityPreset`                                 | Thanos Ruler pod affinity preset                                                                                                 | `""`                     |
| `ruler.podAntiAffinityPreset`                             | Thanos Ruler pod anti-affinity preset. Ignored if `ruler.affinity` is set. Allowed values: `soft` or `hard`                      | `soft`                   |
| `ruler.nodeAffinityPreset.type`                           | Thanos Ruler node affinity preset type. Ignored if `ruler.affinity` is set. Allowed values: `soft` or `hard`                     | `""`                     |
| `ruler.nodeAffinityPreset.key`                            | Thanos Ruler node label key to match. Ignored if `ruler.affinity` is set.                                                        | `""`                     |
| `ruler.nodeAffinityPreset.values`                         | Thanos Ruler node label values to match. Ignored if `ruler.affinity` is set.                                                     | `[]`                     |
| `ruler.affinity`                                          | Thanos Ruler affinity for pod assignment                                                                                         | `{}`                     |
| `ruler.nodeSelector`                                      | Thanos Ruler node labels for pod assignment                                                                                      | `{}`                     |
| `ruler.tolerations`                                       | Thanos Ruler tolerations for pod assignment                                                                                      | `[]`                     |
| `ruler.podLabels`                                         | Thanos Ruler pod labels                                                                                                          | `{}`                     |
| `ruler.podAnnotations`                                    | Annotations for Thanos Ruler pods                                                                                                | `{}`                     |
| `ruler.dnsConfig`                                         | Deployment pod DNS config                                                                                                        | `{}`                     |
| `ruler.dnsPolicy`                                         | Deployment pod DNS policy                                                                                                        | `""`                     |
| `ruler.hostAliases`                                       | Deployment pod host aliases                                                                                                      | `[]`                     |
| `ruler.lifecycleHooks`                                    | for the Thanos Ruler container(s) to automate configuration before or after startup                                              | `{}`                     |
| `ruler.priorityClassName`                                 | Thanos Ruler priorityClassName                                                                                                   | `""`                     |
| `ruler.schedulerName`                                     | Name of the k8s scheduler (other than default) for Thanos Ruler pods                                                             | `""`                     |
| `ruler.topologySpreadConstraints`                         | Topology Spread Constraints for Thanos Ruler pods assignment spread across your cluster among failure-domains                    | `[]`                     |
| `ruler.service.type`                                      | Kubernetes service type                                                                                                          | `ClusterIP`              |
| `ruler.service.ports.http`                                | Thanos Ruler service HTTP port                                                                                                   | `9090`                   |
| `ruler.service.ports.grpc`                                | Thanos Ruler service GRPC port                                                                                                   | `10901`                  |
| `ruler.service.nodePorts.http`                            | Specify the Thanos Ruler HTTP nodePort value for the LoadBalancer and NodePort service types                                     | `""`                     |
| `ruler.service.nodePorts.grpc`                            | Specify the Thanos Ruler GRPC nodePort value for the LoadBalancer and NodePort service types                                     | `""`                     |
| `ruler.service.clusterIP`                                 | Thanos Ruler service clusterIP IP                                                                                                | `""`                     |
| `ruler.service.loadBalancerIP`                            | Load balancer IP if service type is `LoadBalancer`                                                                               | `""`                     |
| `ruler.service.loadBalancerSourceRanges`                  | Address that are allowed when service is LoadBalancer                                                                            | `[]`                     |
| `ruler.service.externalTrafficPolicy`                     | Thanos Ruler service externalTrafficPolicy                                                                                       | `Cluster`                |
| `ruler.service.labels`                                    | Extra labels for Thanos Ruler service                                                                                            | `{}`                     |
| `ruler.service.annotations`                               | Annotations for Thanos Ruler service                                                                                             | `{}`                     |
| `ruler.service.extraPorts`                                | Extra ports to expose in the Thanos Ruler service                                                                                | `[]`                     |
| `ruler.service.labelSelectorsOverride`                    | Selector for Thanos Query service                                                                                                | `{}`                     |
| `ruler.service.additionalHeadless`                        | Additional Headless service                                                                                                      | `false`                  |
| `ruler.service.headless.annotations`                      | Annotations for the headless service.                                                                                            | `{}`                     |
| `ruler.persistence.enabled`                               | Enable data persistence using PVC(s) on Thanos Ruler pods                                                                        | `true`                   |
| `ruler.persistence.storageClass`                          | Specify the `storageClass` used to provision the volume                                                                          | `""`                     |
| `ruler.persistence.accessModes`                           | PVC Access Modes for data volume                                                                                                 | `["ReadWriteOnce"]`      |
| `ruler.persistence.size`                                  | PVC Storage Request for data volume                                                                                              | `8Gi`                    |
| `ruler.persistence.annotations`                           | Annotations for the PVC                                                                                                          | `{}`                     |
| `ruler.persistence.existingClaim`                         | Name of an existing PVC to use                                                                                                   | `""`                     |
| `ruler.automountServiceAccountToken`                      | Enable/disable auto mounting of the service account token only for the sts                                                       | `true`                   |
| `ruler.serviceAccount.create`                             | Specifies whether a ServiceAccount should be created                                                                             | `true`                   |
| `ruler.serviceAccount.name`                               | Name of the service account to use. If not set and create is true, a name is generated using the fullname template.              | `""`                     |
| `ruler.serviceAccount.annotations`                        | Annotations for Thanos Ruler Service Account                                                                                     | `{}`                     |
| `ruler.serviceAccount.automountServiceAccountToken`       | Enable/disable auto mounting of the service account token                                                                        | `true`                   |
| `ruler.autoscaling.enabled`                               | Enable autoscaling for Thanos Ruler                                                                                              | `false`                  |
| `ruler.autoscaling.minReplicas`                           | Minimum number of Thanos Ruler replicas                                                                                          | `""`                     |
| `ruler.autoscaling.maxReplicas`                           | Maximum number of Thanos Ruler replicas                                                                                          | `""`                     |
| `ruler.autoscaling.targetCPU`                             | Target CPU utilization percentage                                                                                                | `""`                     |
| `ruler.autoscaling.targetMemory`                          | Target Memory utilization percentage                                                                                             | `""`                     |
| `ruler.pdb.create`                                        | Enable/disable a Pod Disruption Budget creation for Thanos Ruler                                                                 | `false`                  |
| `ruler.pdb.minAvailable`                                  | Minimum number/percentage of pods that should remain scheduled                                                                   | `1`                      |
| `ruler.pdb.maxUnavailable`                                | Maximum number/percentage of pods that may be made unavailable                                                                   | `""`                     |
| `ruler.ingress.enabled`                                   | Enable ingress controller resource                                                                                               | `false`                  |
| `ruler.ingress.hostname`                                  | Default host for the ingress resource                                                                                            | `thanos-ruler.local`     |
| `ruler.ingress.ingressClassName`                          | IngressClass that will be be used to implement the Ingress (Kubernetes 1.18+)                                                    | `""`                     |
| `ruler.ingress.annotations`                               | Additional annotations for the Ingress resource. To enable certificate autogeneration, place here your cert-manager annotations. | `{}`                     |
| `ruler.ingress.extraHosts`                                | The list of additional hostnames to be covered with this ingress record.                                                         | `[]`                     |
| `ruler.ingress.extraTls`                                  | The tls configuration for additional hostnames to be covered with this ingress record.                                           | `[]`                     |
| `ruler.ingress.secrets`                                   | If you're providing your own certificates, please use this to add the certificates as secrets                                    | `[]`                     |
| `ruler.ingress.extraRules`                                | Additional rules to be covered with this ingress record                                                                          | `[]`                     |
| `ruler.ingress.apiVersion`                                | Force Ingress API version (automatically detected if not set)                                                                    | `""`                     |
| `ruler.ingress.path`                                      | Ingress path                                                                                                                     | `/`                      |
| `ruler.ingress.pathType`                                  | Ingress path type                                                                                                                | `ImplementationSpecific` |

### Thanos Receive parameters

| Name                                                        | Description                                                                                                                      | Value                    |
| ----------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------- | ------------------------ |
| `receive.enabled`                                           | Enable/disable Thanos Receive component                                                                                          | `false`                  |
| `receive.mode`                                              | Mode to run receiver in. Valid options are "standalone" or "dual-mode"                                                           | `standalone`             |
| `receive.logLevel`                                          | Thanos Receive log level                                                                                                         | `info`                   |
| `receive.logFormat`                                         | Thanos Receive log format                                                                                                        | `logfmt`                 |
| `receive.tsdbRetention`                                     | Thanos Receive TSDB retention period                                                                                             | `15d`                    |
| `receive.replicationFactor`                                 | Thanos Receive replication-factor                                                                                                | `1`                      |
| `receive.config`                                            | Receive Hashring configuration                                                                                                   | `[]`                     |
| `receive.existingConfigmap`                                 | Name of existing ConfigMap with Thanos Receive Hashring configuration                                                            | `""`                     |
| `receive.replicaLabel`                                      | Label to treat as a replica indicator along which data is de-duplicated                                                          | `replica`                |
| `receive.grpc.server.tls.enabled`                           | Enable TLS encryption in the GRPC server                                                                                         | `false`                  |
| `receive.grpc.server.tls.autoGenerated`                     | Create self-signed TLS certificates. Currently only supports PEM certificates                                                    | `false`                  |
| `receive.grpc.server.tls.cert`                              | TLS Certificate for GRPC server - ignored if existingSecret is provided                                                          | `""`                     |
| `receive.grpc.server.tls.key`                               | TLS Key for GRPC server - ignored if existingSecret is provided                                                                  | `""`                     |
| `receive.grpc.server.tls.ca`                                | TLS CA to verify clients against - ignored if existingSecret is provided                                                         | `""`                     |
| `receive.grpc.server.tls.existingSecret`                    | Existing secret containing your own TLS certificates                                                                             | `{}`                     |
| `receive.extraEnvVars`                                      | Extra environment variables for Thanos Receive container                                                                         | `[]`                     |
| `receive.extraEnvVarsCM`                                    | Name of existing ConfigMap containing extra env vars for Thanos Receive nodes                                                    | `""`                     |
| `receive.extraEnvVarsSecret`                                | Name of existing Secret containing extra env vars for Thanos Receive nodes                                                       | `""`                     |
| `receive.extraFlags`                                        | Extra Flags to passed to Thanos Receive                                                                                          | `[]`                     |
| `receive.command`                                           | Override default container command (useful when using custom images)                                                             | `[]`                     |
| `receive.args`                                              | Override default container args (useful when using custom images)                                                                | `[]`                     |
| `receive.replicaCount`                                      | Number of Thanos Receive replicas to deploy                                                                                      | `1`                      |
| `receive.updateStrategy.type`                               | Update strategy type for Thanos Receive replicas                                                                                 | `RollingUpdate`          |
| `receive.podManagementPolicy`                               |                                                                                                                                  | `OrderedReady`           |
| `receive.podManagementPolicy`                               | Statefulset Pod management policy: OrderedReady (default) or Parallel                                                            | `OrderedReady`           |
| `receive.podSecurityContext.enabled`                        | Enable security context for the Thanos Receive pods                                                                              | `true`                   |
| `receive.podSecurityContext.fsGroup`                        | Group ID for the filesystem used by Thanos Receive pods                                                                          | `1001`                   |
| `receive.containerSecurityContext.enabled`                  | Enabled containers' Security Context                                                                                             | `true`                   |
| `receive.containerSecurityContext.runAsUser`                | Set containers' Security Context runAsUser                                                                                       | `1001`                   |
| `receive.containerSecurityContext.runAsNonRoot`             | Set container's Security Context runAsNonRoot                                                                                    | `true`                   |
| `receive.containerSecurityContext.privileged`               | Set container's Security Context privileged                                                                                      | `false`                  |
| `receive.containerSecurityContext.readOnlyRootFilesystem`   | Set container's Security Context readOnlyRootFilesystem                                                                          | `true`                   |
| `receive.containerSecurityContext.allowPrivilegeEscalation` | Set container's Security Context allowPrivilegeEscalation                                                                        | `false`                  |
| `receive.containerSecurityContext.capabilities.drop`        | List of capabilities to be dropped                                                                                               | `["ALL"]`                |
| `receive.containerSecurityContext.seccompProfile.type`      | Set container's Security Context seccomp profile                                                                                 | `RuntimeDefault`         |
| `receive.resources.limits`                                  | The resources limits for the Thanos Receive container                                                                            | `{}`                     |
| `receive.resources.requests`                                | The requested resources for the Thanos Receive container                                                                         | `{}`                     |
| `receive.livenessProbe.enabled`                             | Enable livenessProbe on Thanos Receive containers                                                                                | `true`                   |
| `receive.livenessProbe.initialDelaySeconds`                 | Initial delay seconds for livenessProbe                                                                                          | `30`                     |
| `receive.livenessProbe.periodSeconds`                       | Period seconds for livenessProbe                                                                                                 | `10`                     |
| `receive.livenessProbe.timeoutSeconds`                      | Timeout seconds for livenessProbe                                                                                                | `30`                     |
| `receive.livenessProbe.failureThreshold`                    | Failure threshold for livenessProbe                                                                                              | `6`                      |
| `receive.livenessProbe.successThreshold`                    | Success threshold for livenessProbe                                                                                              | `1`                      |
| `receive.readinessProbe.enabled`                            | Enable readinessProbe on Thanos Receive containers                                                                               | `true`                   |
| `receive.readinessProbe.initialDelaySeconds`                | Initial delay seconds for readinessProbe                                                                                         | `30`                     |
| `receive.readinessProbe.periodSeconds`                      | Period seconds for readinessProbe                                                                                                | `10`                     |
| `receive.readinessProbe.timeoutSeconds`                     | Timeout seconds for readinessProbe                                                                                               | `30`                     |
| `receive.readinessProbe.failureThreshold`                   | Failure threshold for readinessProbe                                                                                             | `6`                      |
| `receive.readinessProbe.successThreshold`                   | Success threshold for readinessProbe                                                                                             | `1`                      |
| `receive.startupProbe.enabled`                              | Enable startupProbe on Thanos Receive containers                                                                                 | `false`                  |
| `receive.startupProbe.initialDelaySeconds`                  | Initial delay seconds for startupProbe                                                                                           | `5`                      |
| `receive.startupProbe.periodSeconds`                        | Period seconds for startupProbe                                                                                                  | `5`                      |
| `receive.startupProbe.timeoutSeconds`                       | Timeout seconds for startupProbe                                                                                                 | `1`                      |
| `receive.startupProbe.failureThreshold`                     | Failure threshold for startupProbe                                                                                               | `15`                     |
| `receive.startupProbe.successThreshold`                     | Success threshold for startupProbe                                                                                               | `1`                      |
| `receive.customLivenessProbe`                               | Custom livenessProbe that overrides the default one                                                                              | `{}`                     |
| `receive.customReadinessProbe`                              | Custom readinessProbe that overrides the default one                                                                             | `{}`                     |
| `receive.customStartupProbe`                                | Custom startupProbe that overrides the default one                                                                               | `{}`                     |
| `receive.initContainers`                                    | Add additional init containers to the Thanos Receive pods                                                                        | `[]`                     |
| `receive.sidecars`                                          | Extra containers running as sidecars to Thanos Receive pods                                                                      | `[]`                     |
| `receive.extraVolumes`                                      | Extra volumes to add to Thanos Receive                                                                                           | `[]`                     |
| `receive.extraVolumeMounts`                                 | Extra volume mounts to add to the receive container                                                                              | `[]`                     |
| `receive.podAffinityPreset`                                 | Thanos Receive pod affinity preset                                                                                               | `""`                     |
| `receive.podAntiAffinityPreset`                             | Thanos Receive pod anti-affinity preset. Ignored if `ruler.affinity` is set. Allowed values: `soft` or `hard`                    | `soft`                   |
| `receive.nodeAffinityPreset.type`                           | Thanos Receive node affinity preset type. Ignored if `receive.affinity` is set. Allowed values: `soft` or `hard`                 | `""`                     |
| `receive.nodeAffinityPreset.key`                            | Thanos Receive node label key to match. Ignored if `receive.affinity` is set.                                                    | `""`                     |
| `receive.nodeAffinityPreset.values`                         | Thanos Receive node label values to match. Ignored if `receive.affinity` is set.                                                 | `[]`                     |
| `receive.affinity`                                          | Thanos Receive affinity for pod assignment                                                                                       | `{}`                     |
| `receive.nodeSelector`                                      | Thanos Receive node labels for pod assignment                                                                                    | `{}`                     |
| `receive.tolerations`                                       | Thanos Receive tolerations for pod assignment                                                                                    | `[]`                     |
| `receive.statefulsetLabels`                                 | Thanos Receive statefulset labels                                                                                                | `{}`                     |
| `receive.podLabels`                                         | Thanos Receive pod labels                                                                                                        | `{}`                     |
| `receive.podAnnotations`                                    | Annotations for Thanos Receive pods                                                                                              | `{}`                     |
| `receive.dnsConfig`                                         | Deployment pod DNS config                                                                                                        | `{}`                     |
| `receive.dnsPolicy`                                         | Deployment pod DNS policy                                                                                                        | `""`                     |
| `receive.hostAliases`                                       | Deployment pod host aliases                                                                                                      | `[]`                     |
| `receive.lifecycleHooks`                                    | for the Thanos Receive container(s) to automate configuration before or after startup                                            | `{}`                     |
| `receive.priorityClassName`                                 | Thanos Receive priorityClassName                                                                                                 | `""`                     |
| `receive.schedulerName`                                     | Name of the k8s scheduler (other than default) for Thanos Receive pods                                                           | `""`                     |
| `receive.topologySpreadConstraints`                         | Topology Spread Constraints for Thanos Receive pods assignment spread across your cluster among failure-domains                  | `[]`                     |
| `receive.service.type`                                      | Kubernetes service type                                                                                                          | `ClusterIP`              |
| `receive.service.ports.http`                                | Thanos Ruler service HTTP port                                                                                                   | `10902`                  |
| `receive.service.ports.grpc`                                | Thanos Ruler service GRPC port                                                                                                   | `10901`                  |
| `receive.service.ports.remote`                              | Thanos Ruler service remote port                                                                                                 | `19291`                  |
| `receive.service.nodePorts.http`                            | Specify the Thanos Ruler HTTP nodePort value for the LoadBalancer and NodePort service types                                     | `""`                     |
| `receive.service.nodePorts.grpc`                            | Specify the Thanos Ruler GRPC nodePort value for the LoadBalancer and NodePort service types                                     | `""`                     |
| `receive.service.nodePorts.remote`                          | Specify the Thanos Ruler remote nodePort value for the LoadBalancer and NodePort service types                                   | `""`                     |
| `receive.service.clusterIP`                                 | Thanos Ruler service clusterIP IP                                                                                                | `""`                     |
| `receive.service.loadBalancerIP`                            | Load balancer IP if service type is `LoadBalancer`                                                                               | `""`                     |
| `receive.service.loadBalancerSourceRanges`                  | Addresses that are allowed when service is LoadBalancer                                                                          | `[]`                     |
| `receive.service.externalTrafficPolicy`                     | Thanos Ruler service externalTrafficPolicy                                                                                       | `Cluster`                |
| `receive.service.labels`                                    | Extra labels for Thanos Receive service                                                                                          | `{}`                     |
| `receive.service.annotations`                               | Annotations for Thanos Receive service                                                                                           | `{}`                     |
| `receive.service.extraPorts`                                | Extra ports to expose in the Thanos Receive service                                                                              | `[]`                     |
| `receive.service.labelSelectorsOverride`                    | Selector for Thanos receive service                                                                                              | `{}`                     |
| `receive.service.additionalHeadless`                        | Additional Headless service                                                                                                      | `false`                  |
| `receive.service.headless.annotations`                      | Annotations for the headless service.                                                                                            | `{}`                     |
| `receive.automountServiceAccountToken`                      | Enable/disable auto mounting of the service account token only for the sts                                                       | `true`                   |
| `receive.serviceAccount.create`                             | Specifies whether a ServiceAccount should be created                                                                             | `true`                   |
| `receive.serviceAccount.name`                               | Name of the service account to use. If not set and create is true, a name is generated using the fullname template.              | `""`                     |
| `receive.serviceAccount.annotations`                        | Annotations for Thanos Receive Service Account                                                                                   | `{}`                     |
| `receive.serviceAccount.automountServiceAccountToken`       | Enable/disable auto mounting of the service account token                                                                        | `true`                   |
| `receive.autoscaling.enabled`                               | Enable autoscaling for Thanos Receive                                                                                            | `false`                  |
| `receive.autoscaling.minReplicas`                           | Minimum number of Thanos Receive replicas                                                                                        | `""`                     |
| `receive.autoscaling.maxReplicas`                           | Maximum number of Thanos Receive replicas                                                                                        | `""`                     |
| `receive.autoscaling.targetCPU`                             | Target CPU utilization percentage                                                                                                | `""`                     |
| `receive.autoscaling.targetMemory`                          | Target Memory utilization percentage                                                                                             | `""`                     |
| `receive.pdb.create`                                        | Enable/disable a Pod Disruption Budget creation for Thanos Receive                                                               | `false`                  |
| `receive.pdb.minAvailable`                                  | Minimum number/percentage of pods that should remain scheduled                                                                   | `1`                      |
| `receive.pdb.maxUnavailable`                                | Maximum number/percentage of pods that may be made unavailable                                                                   | `""`                     |
| `receive.persistence.enabled`                               | Enable data persistence using PVC(s) on Thanos Receive pods                                                                      | `true`                   |
| `receive.persistence.storageClass`                          | Specify the `storageClass` used to provision the volume                                                                          | `""`                     |
| `receive.persistence.accessModes`                           | PVC Access Modes for data volume                                                                                                 | `["ReadWriteOnce"]`      |
| `receive.persistence.size`                                  | PVC Storage Request for data volume                                                                                              | `8Gi`                    |
| `receive.persistence.annotations`                           | Annotations for the PVC                                                                                                          | `{}`                     |
| `receive.persistence.existingClaim`                         | Name of an existing PVC to use                                                                                                   | `""`                     |
| `receive.ingress.enabled`                                   | Set to true to enable ingress record generation                                                                                  | `false`                  |
| `receive.ingress.hostname`                                  | When the ingress is enabled, a host pointing to this will be created                                                             | `thanos-receive.local`   |
| `receive.ingress.ingressClassName`                          | IngressClass that will be be used to implement the Ingress (Kubernetes 1.18+)                                                    | `""`                     |
| `receive.ingress.annotations`                               | Additional annotations for the Ingress resource. To enable certificate autogeneration, place here your cert-manager annotations. | `{}`                     |
| `receive.ingress.extraHosts`                                | The list of additional hostnames to be covered with this ingress record.                                                         | `[]`                     |
| `receive.ingress.extraTls`                                  | The tls configuration for additional hostnames to be covered with this ingress record.                                           | `[]`                     |
| `receive.ingress.secrets`                                   | If you're providing your own certificates, please use this to add the certificates as secrets                                    | `[]`                     |
| `receive.ingress.extraRules`                                | Additional rules to be covered with this ingress record                                                                          | `[]`                     |
| `receive.ingress.tls`                                       | Enable TLS configuration for the hostname defined at `receive.ingress.hostname` parameter                                        | `false`                  |
| `receive.ingress.selfSigned`                                | Create a TLS secret for this ingress record using self-signed certificates generated by Helm                                     | `false`                  |
| `receive.ingress.apiVersion`                                | Override API Version (automatically detected if not set)                                                                         | `""`                     |
| `receive.ingress.path`                                      | Ingress Path                                                                                                                     | `/`                      |
| `receive.ingress.pathType`                                  | Ingress Path type                                                                                                                | `ImplementationSpecific` |

### Thanos Receive Distributor parameters

| Name                                                                   | Description                                                                                                                 | Value            |
| ---------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------- | ---------------- |
| `receiveDistributor.enabled`                                           | Enable/disable Thanos Receive Distributor component                                                                         | `false`          |
| `receiveDistributor.logLevel`                                          | Thanos Receive Distributor log level                                                                                        | `info`           |
| `receiveDistributor.logFormat`                                         | Thanos Receive Distributor log format                                                                                       | `logfmt`         |
| `receiveDistributor.replicaLabel`                                      | Label to treat as a replica indicator along which data is de-duplicated                                                     | `replica`        |
| `receiveDistributor.replicationFactor`                                 | Thanos Receive Distributor replication-factor                                                                               | `1`              |
| `receiveDistributor.extraEnvVars`                                      | Extra environment variables for Thanos Receive Distributor container                                                        | `[]`             |
| `receiveDistributor.extraEnvVarsCM`                                    | Name of existing ConfigMap containing extra env vars for Thanos Receive Distributor nodes                                   | `""`             |
| `receiveDistributor.extraEnvVarsSecret`                                | Name of existing Secret containing extra env vars for Thanos Receive Distributor nodes                                      | `""`             |
| `receiveDistributor.extraFlags`                                        | Extra Flags to passed to Thanos Receive Distributor                                                                         | `[]`             |
| `receiveDistributor.command`                                           | Override default container command (useful when using custom images)                                                        | `[]`             |
| `receiveDistributor.args`                                              | Override default container args (useful when using custom images)                                                           | `[]`             |
| `receiveDistributor.replicaCount`                                      | Number of Thanos Receive Distributor replicas to deploy                                                                     | `1`              |
| `receiveDistributor.updateStrategy.type`                               | Update strategy type for Thanos Receive Distributor replicas                                                                | `RollingUpdate`  |
| `receiveDistributor.podSecurityContext.enabled`                        | Enable security context for the Thanos Receive Distributor pods                                                             | `true`           |
| `receiveDistributor.podSecurityContext.fsGroup`                        | Group ID for the filesystem used by Thanos Receive Distributor pods                                                         | `1001`           |
| `receiveDistributor.containerSecurityContext.enabled`                  | Enabled containers' Security Context                                                                                        | `true`           |
| `receiveDistributor.containerSecurityContext.runAsUser`                | Set containers' Security Context runAsUser                                                                                  | `1001`           |
| `receiveDistributor.containerSecurityContext.runAsNonRoot`             | Set container's Security Context runAsNonRoot                                                                               | `true`           |
| `receiveDistributor.containerSecurityContext.privileged`               | Set container's Security Context privileged                                                                                 | `false`          |
| `receiveDistributor.containerSecurityContext.readOnlyRootFilesystem`   | Set container's Security Context readOnlyRootFilesystem                                                                     | `true`           |
| `receiveDistributor.containerSecurityContext.allowPrivilegeEscalation` | Set container's Security Context allowPrivilegeEscalation                                                                   | `false`          |
| `receiveDistributor.containerSecurityContext.capabilities.drop`        | List of capabilities to be dropped                                                                                          | `["ALL"]`        |
| `receiveDistributor.containerSecurityContext.seccompProfile.type`      | Set container's Security Context seccomp profile                                                                            | `RuntimeDefault` |
| `receiveDistributor.resources.limits`                                  | The resources limits for the Thanos Receive container                                                                       | `{}`             |
| `receiveDistributor.resources.requests`                                | The requested resources for the Thanos Receive container                                                                    | `{}`             |
| `receiveDistributor.livenessProbe.enabled`                             | Enable livenessProbe on Thanos Receive Distributor containers                                                               | `true`           |
| `receiveDistributor.livenessProbe.initialDelaySeconds`                 | Initial delay seconds for livenessProbe                                                                                     | `30`             |
| `receiveDistributor.livenessProbe.periodSeconds`                       | Period seconds for livenessProbe                                                                                            | `10`             |
| `receiveDistributor.livenessProbe.timeoutSeconds`                      | Timeout seconds for livenessProbe                                                                                           | `30`             |
| `receiveDistributor.livenessProbe.failureThreshold`                    | Failure threshold for livenessProbe                                                                                         | `6`              |
| `receiveDistributor.livenessProbe.successThreshold`                    | Success threshold for livenessProbe                                                                                         | `1`              |
| `receiveDistributor.readinessProbe.enabled`                            | Enable readinessProbe on Thanos Receive Distributor containers                                                              | `true`           |
| `receiveDistributor.readinessProbe.initialDelaySeconds`                | Initial delay seconds for readinessProbe                                                                                    | `30`             |
| `receiveDistributor.readinessProbe.periodSeconds`                      | Period seconds for readinessProbe                                                                                           | `10`             |
| `receiveDistributor.readinessProbe.timeoutSeconds`                     | Timeout seconds for readinessProbe                                                                                          | `30`             |
| `receiveDistributor.readinessProbe.failureThreshold`                   | Failure threshold for readinessProbe                                                                                        | `6`              |
| `receiveDistributor.readinessProbe.successThreshold`                   | Success threshold for readinessProbe                                                                                        | `1`              |
| `receiveDistributor.startupProbe.enabled`                              | Enable startupProbe on Thanos Receive Distributor containers                                                                | `false`          |
| `receiveDistributor.startupProbe.initialDelaySeconds`                  | Initial delay seconds for startupProbe                                                                                      | `5`              |
| `receiveDistributor.startupProbe.periodSeconds`                        | Period seconds for startupProbe                                                                                             | `5`              |
| `receiveDistributor.startupProbe.timeoutSeconds`                       | Timeout seconds for startupProbe                                                                                            | `1`              |
| `receiveDistributor.startupProbe.failureThreshold`                     | Failure threshold for startupProbe                                                                                          | `15`             |
| `receiveDistributor.startupProbe.successThreshold`                     | Success threshold for startupProbe                                                                                          | `1`              |
| `receiveDistributor.customLivenessProbe`                               | Custom livenessProbe that overrides the default one                                                                         | `{}`             |
| `receiveDistributor.customReadinessProbe`                              | Custom readinessProbe that overrides the default one                                                                        | `{}`             |
| `receiveDistributor.customStartupProbe`                                | Custom startupProbe that overrides the default one                                                                          | `{}`             |
| `receiveDistributor.initContainers`                                    | Add additional init containers to the Thanos Receive Distributor pods                                                       | `[]`             |
| `receiveDistributor.sidecars`                                          | Extra containers running as sidecars to Thanos Receive Distributor pods                                                     | `[]`             |
| `receiveDistributor.extraVolumes`                                      | Extra volumes to add to Thanos Receive Distributor                                                                          | `[]`             |
| `receiveDistributor.extraVolumeMounts`                                 | Extra volume mounts to add to the receive distributor container                                                             | `[]`             |
| `receiveDistributor.podAffinityPreset`                                 | Thanos Receive pod affinity preset                                                                                          | `""`             |
| `receiveDistributor.podAntiAffinityPreset`                             | Thanos Receive pod anti-affinity preset. Ignored if `receiveDistributor.affinity` is set. Allowed values: `soft` or `hard`  | `soft`           |
| `receiveDistributor.nodeAffinityPreset.type`                           | Thanos Receive node affinity preset type. Ignored if `receiveDistributor.affinity` is set. Allowed values: `soft` or `hard` | `""`             |
| `receiveDistributor.nodeAffinityPreset.key`                            | Thanos Receive node label key to match. Ignored if `receiveDistributor.affinity` is set.                                    | `""`             |
| `receiveDistributor.nodeAffinityPreset.values`                         | Thanos Receive node label values to match. Ignored if `receiveDistributor.affinity` is set.                                 | `[]`             |
| `receiveDistributor.affinity`                                          | Thanos Receive Distributor affinity for pod assignment                                                                      | `{}`             |
| `receiveDistributor.nodeSelector`                                      | Thanos Receive Distributor node labels for pod assignment                                                                   | `{}`             |
| `receiveDistributor.tolerations`                                       | Thanos Receive Distributor tolerations for pod assignment                                                                   | `[]`             |
| `receiveDistributor.podLabels`                                         | Thanos Receive Distributor pod labels                                                                                       | `{}`             |
| `receiveDistributor.podAnnotations`                                    | Annotations for Thanos Receive Distributor pods                                                                             | `{}`             |
| `receiveDistributor.dnsConfig`                                         | Deployment pod DNS config                                                                                                   | `{}`             |
| `receiveDistributor.dnsPolicy`                                         | Deployment pod DNS policy                                                                                                   | `""`             |
| `receiveDistributor.hostAliases`                                       | Deployment pod host aliases                                                                                                 | `[]`             |
| `receiveDistributor.lifecycleHooks`                                    | for the Thanos Receive Distributor container(s) to automate configuration before or after startup                           | `{}`             |
| `receiveDistributor.priorityClassName`                                 | Thanos Receive Distributor priorityClassName                                                                                | `""`             |
| `receiveDistributor.schedulerName`                                     | Name of the k8s scheduler (other than default) for Thanos Receive Distributor pods                                          | `""`             |
| `receiveDistributor.topologySpreadConstraints`                         | Topology Spread Constraints for Thanos Receive Distributor pods assignment spread across your cluster among failure-domains | `[]`             |
| `receiveDistributor.automountServiceAccountToken`                      | Enable/disable auto mounting of the service account token only for the deployment                                           | `true`           |
| `receiveDistributor.serviceAccount.create`                             | Specifies whether a ServiceAccount should be created                                                                        | `true`           |
| `receiveDistributor.serviceAccount.name`                               | Name of the service account to use. If not set and create is true, a name is generated using the fullname template.         | `""`             |
| `receiveDistributor.serviceAccount.annotations`                        | Annotations for Thanos Receive Distributor Service Account                                                                  | `{}`             |
| `receiveDistributor.serviceAccount.automountServiceAccountToken`       | Enable/disable auto mounting of the service account token                                                                   | `true`           |
| `receiveDistributor.autoscaling.enabled`                               | Enable autoscaling for Thanos Receive Distributor                                                                           | `false`          |
| `receiveDistributor.autoscaling.minReplicas`                           | Minimum number of Thanos Receive Distributor replicas                                                                       | `""`             |
| `receiveDistributor.autoscaling.maxReplicas`                           | Maximum number of Thanos Receive Distributor replicas                                                                       | `""`             |
| `receiveDistributor.autoscaling.targetCPU`                             | Target CPU utilization percentage                                                                                           | `""`             |
| `receiveDistributor.autoscaling.targetMemory`                          | Target Memory utilization percentage                                                                                        | `""`             |
| `receiveDistributor.pdb.create`                                        | Enable/disable a Pod Disruption Budget creation for Thanos Receive Distributor                                              | `false`          |
| `receiveDistributor.pdb.minAvailable`                                  | Minimum number/percentage of pods that should remain scheduled                                                              | `1`              |
| `receiveDistributor.pdb.maxUnavailable`                                | Maximum number/percentage of pods that may be made unavailable                                                              | `""`             |

### Metrics parameters

| Name                                                                                    | Description                                                                                                                                                   | Value                |
| --------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------------- |
| `metrics.enabled`                                                                       | Enable the export of Prometheus metrics                                                                                                                       | `false`              |
| `metrics.serviceMonitor.enabled`                                                        | Specify if a ServiceMonitor will be deployed for Prometheus Operator                                                                                          | `false`              |
| `metrics.serviceMonitor.namespace`                                                      | Namespace in which Prometheus is running                                                                                                                      | `""`                 |
| `metrics.serviceMonitor.labels`                                                         | Extra labels for the ServiceMonitor                                                                                                                           | `{}`                 |
| `metrics.serviceMonitor.jobLabel`                                                       | The name of the label on the target service to use as the job name in Prometheus                                                                              | `""`                 |
| `metrics.serviceMonitor.interval`                                                       | How frequently to scrape metrics                                                                                                                              | `""`                 |
| `metrics.serviceMonitor.scrapeTimeout`                                                  | Timeout after which the scrape is ended                                                                                                                       | `""`                 |
| `metrics.serviceMonitor.metricRelabelings`                                              | Specify additional relabeling of metrics                                                                                                                      | `[]`                 |
| `metrics.serviceMonitor.relabelings`                                                    | Specify general relabeling                                                                                                                                    | `[]`                 |
| `metrics.serviceMonitor.selector`                                                       | Prometheus instance selector labels                                                                                                                           | `{}`                 |
| `metrics.serviceMonitor.extraParameters`                                                | Any extra parameter to be added to the endpoint configured in the ServiceMonitor                                                                              | `{}`                 |
| `metrics.prometheusRule.enabled`                                                        | If `true`, creates a Prometheus Operator PrometheusRule (also requires `metrics.enabled` to be `true`)                                                        | `false`              |
| `metrics.prometheusRule.default.absent_rules`                                           | Enable absent_rules when metrics.prometheusRule.default.create is false (also requires `metrics.enabled` to be `true`)                                        |                      |
| `metrics.prometheusRule.default.compaction`                                             | Enable compaction rules when metrics.prometheusRule.default.create is false (also requires `metrics.enabled` to be `true`)                                    |                      |
| `metrics.prometheusRule.default.query`                                                  | Enable query when metrics.prometheusRule.default.create is false (also requires `metrics.enabled` to be `true`)                                               |                      |
| `metrics.prometheusRule.default.receive`                                                | Enable receive rules when metrics.prometheusRule.default.create is false (also requires `metrics.enabled` to be `true`)                                       |                      |
| `metrics.prometheusRule.default.replicate`                                              | Enable replicate rules when metrics.prometheusRule.default.create is false (also requires `metrics.enabled` to be `true`)                                     |                      |
| `metrics.prometheusRule.default.ruler`                                                  | Enable ruler rules when metrics.prometheusRule.default.create is false (also requires `metrics.enabled` to be `true`)                                         |                      |
| `metrics.prometheusRule.default.sidecar`                                                | Enable sidecar rules when metrics.prometheusRule.default.create is false (also requires `metrics.enabled` to be `true`)                                       |                      |
| `metrics.prometheusRule.default.sidecarJobRegex`                                        | Allows the customization of the thanos-sidecar job name to use in the sidecar prometheus alerts                                                               | `.*thanos-sidecar.*` |
| `metrics.prometheusRule.default.store_gateway`                                          | Enable store_gateway rules when metrics.prometheusRule.default.create is false (also requires `metrics.enabled` to be `true`)                                 |                      |
| `metrics.prometheusRule.default.create`                                                 | would create all default prometheus alerts                                                                                                                    | `false`              |
| `metrics.prometheusRule.default.disabled.ThanosCompactIsDown`                           | Disable ThanosCompactIsDown rule when metrics.prometheusRule.default.create or metrics.prometheusRule.default.absent_rules is true                            |                      |
| `metrics.prometheusRule.default.disabled.ThanosQueryIsDown`                             | Disable ThanosQueryIsDown rule when metrics.prometheusRule.default.create or metrics.prometheusRule.default.absent_rules is true                              |                      |
| `metrics.prometheusRule.default.disabled.ThanosReceiveIsDown`                           | Disable ThanosReceiveIsDown rule when metrics.prometheusRule.default.create or metrics.prometheusRule.default.absent_rules is true                            |                      |
| `metrics.prometheusRule.default.disabled.ThanosRuleIsDown`                              | Disable ThanosRuleIsDown rule when metrics.prometheusRule.default.create or metrics.prometheusRule.default.absent_rules is true                               |                      |
| `metrics.prometheusRule.default.disabled.ThanosSidecarIsDown`                           | Disable ThanosSidecarIsDown rule when metrics.prometheusRule.default.create or metrics.prometheusRule.default.absent_rules is true                            |                      |
| `metrics.prometheusRule.default.disabled.ThanosStoreIsDown`                             | Disable ThanosStoreIsDown rule when metrics.prometheusRule.default.create or metrics.prometheusRule.default.absent_rules is true                              |                      |
| `metrics.prometheusRule.default.disabled.ThanosCompactMultipleRunning`                  | Disable ThanosCompactMultipleRunning rule when metrics.prometheusRule.default.create or metrics.prometheusRule.default.compaction is true                     |                      |
| `metrics.prometheusRule.default.disabled.ThanosCompactHalted`                           | Disable ThanosCompactMultipleRunning rule when metrics.prometheusRule.default.create or metrics.prometheusRule.default.compaction is true                     |                      |
| `metrics.prometheusRule.default.disabled.ThanosCompactHighCompactionFailures`           | Disable ThanosCompactMultipleRunning rule when metrics.prometheusRule.default.create or metrics.prometheusRule.default.compaction is true                     |                      |
| `metrics.prometheusRule.default.disabled.ThanosCompactBucketHighOperationFailures`      | Disable ThanosCompactMultipleRunning rule when metrics.prometheusRule.default.create or metrics.prometheusRule.default.compaction is true                     |                      |
| `metrics.prometheusRule.default.disabled.ThanosCompactHasNotRun`                        | Disable ThanosCompactMultipleRunning rule when metrics.prometheusRule.default.create or metrics.prometheusRule.default.compaction is true                     |                      |
| `metrics.prometheusRule.default.disabled.ThanosQueryHttpRequestQueryErrorRateHigh`      | Disable ThanosQueryHttpRequestQueryErrorRateHigh rule when metrics.prometheusRule.default.create or metrics.prometheusRule.default.query is true              |                      |
| `metrics.prometheusRule.default.disabled.ThanosQueryHttpRequestQueryRangeErrorRateHigh` | Disable ThanosQueryHttpRequestQueryRangeErrorRateHigh rule when metrics.prometheusRule.default.create or metrics.prometheusRule.default.query is true         |                      |
| `metrics.prometheusRule.default.disabled.ThanosQueryGrpcServerErrorRate`                | Disable ThanosQueryGrpcServerErrorRate rule when metrics.prometheusRule.default.create or metrics.prometheusRule.default.query is true                        |                      |
| `metrics.prometheusRule.default.disabled.ThanosQueryGrpcClientErrorRate`                | Disable ThanosQueryGrpcClientErrorRate rule when metrics.prometheusRule.default.create or metrics.prometheusRule.default.query is true                        |                      |
| `metrics.prometheusRule.default.disabled.ThanosQueryHighDNSFailures`                    | Disable ThanosQueryHighDNSFailures rule when metrics.prometheusRule.default.create or metrics.prometheusRule.default.query is true                            |                      |
| `metrics.prometheusRule.default.disabled.ThanosQueryInstantLatencyHigh`                 | Disable ThanosQueryInstantLatencyHigh rule when metrics.prometheusRule.default.create or metrics.prometheusRule.default.query is true                         |                      |
| `metrics.prometheusRule.default.disabled.ThanosQueryRangeLatencyHigh`                   | Disable ThanosQueryRangeLatencyHigh rule when metrics.prometheusRule.default.create or metrics.prometheusRule.default.query is true                           |                      |
| `metrics.prometheusRule.default.disabled.ThanosQueryOverload`                           | Disable ThanosQueryOverload rule when metrics.prometheusRule.default.create or metrics.prometheusRule.default.query is true                                   |                      |
| `metrics.prometheusRule.default.disabled.ThanosReceiveHttpRequestErrorRateHigh`         | Disable ThanosReceiveHttpRequestErrorRateHigh rule when metrics.prometheusRule.default.create or metrics.prometheusRule.default.receive is true               |                      |
| `metrics.prometheusRule.default.disabled.ThanosReceiveHttpRequestLatencyHigh`           | Disable ThanosReceiveHttpRequestLatencyHigh rule when metrics.prometheusRule.default.create or metrics.prometheusRule.default.receive is true                 |                      |
| `metrics.prometheusRule.default.disabled.ThanosReceiveHighReplicationFailures`          | Disable ThanosReceiveHighReplicationFailures rule when metrics.prometheusRule.default.create or metrics.prometheusRule.default.receive is true                |                      |
| `metrics.prometheusRule.default.disabled.ThanosReceiveHighForwardRequestFailures`       | Disable ThanosReceiveHighForwardRequestFailures rule when metrics.prometheusRule.default.create or metrics.prometheusRule.default.receive is true             |                      |
| `metrics.prometheusRule.default.disabled.ThanosReceiveHighHashringFileRefreshFailures`  | Disable ThanosReceiveHighHashringFileRefreshFailures rule when metrics.prometheusRule.default.create or metrics.prometheusRule.default.receive is true        |                      |
| `metrics.prometheusRule.default.disabled.ThanosReceiveConfigReloadFailure`              | Disable ThanosReceiveConfigReloadFailure rule when metrics.prometheusRule.default.create or metrics.prometheusRule.default.receive is true                    |                      |
| `metrics.prometheusRule.default.disabled.ThanosReceiveNoUpload`                         | Disable ThanosReceiveNoUpload rule when metrics.prometheusRule.default.create or metrics.prometheusRule.default.receive is true                               |                      |
| `metrics.prometheusRule.default.disabled.ThanosReceiveTrafficBelowThreshold`            | Disable ThanosReceiveTrafficBelowThreshold rule when metrics.prometheusRule.default.create or metrics.prometheusRule.default.receive is true                  |                      |
| `metrics.prometheusRule.default.disabled.ThanosBucketReplicateErrorRate`                | Disable ThanosBucketReplicateErrorRate rule when metrics.prometheusRule.default.create or metrics.prometheusRule.default.receive is true                      |                      |
| `metrics.prometheusRule.default.disabled.ThanosBucketReplicateRunLatency`               | Disable ThanosBucketReplicateRunLatency rule when metrics.prometheusRule.default.create or metrics.prometheusRule.default.receive is true                     |                      |
| `metrics.prometheusRule.default.disabled.ThanosRuleQueueIsDroppingAlerts`               | Disable ThanosRuleQueueIsDroppingAlerts rule when metrics.prometheusRule.default.create or metrics.prometheusRule.default.ruler is true                       |                      |
| `metrics.prometheusRule.default.disabled.ThanosRuleSenderIsFailingAlerts`               | Disable ThanosRuleSenderIsFailingAlerts rule when metrics.prometheusRule.default.create or metrics.prometheusRule.default.ruler is true                       |                      |
| `metrics.prometheusRule.default.disabled.ThanosRuleHighRuleEvaluationFailures`          | Disable ThanosRuleHighRuleEvaluationFailures rule when metrics.prometheusRule.default.create or metrics.prometheusRule.default.ruler is true                  |                      |
| `metrics.prometheusRule.default.disabled.ThanosRuleHighRuleEvaluationWarnings`          | Disable ThanosRuleHighRuleEvaluationWarnings rule when metrics.prometheusRule.default.create or metrics.prometheusRule.default.ruler is true                  |                      |
| `metrics.prometheusRule.default.disabled.ThanosRuleRuleEvaluationLatencyHigh`           | Disable ThanosRuleRuleEvaluationLatencyHigh rule when metrics.prometheusRule.default.create or metrics.prometheusRule.default.ruler is true                   |                      |
| `metrics.prometheusRule.default.disabled.ThanosRuleGrpcErrorRate`                       | Disable ThanosRuleGrpcErrorRate rule when metrics.prometheusRule.default.create or metrics.prometheusRule.default.ruler is true                               |                      |
| `metrics.prometheusRule.default.disabled.ThanosRuleConfigReloadFailure`                 | Disable ThanosRuleConfigReloadFailure rule when metrics.prometheusRule.default.create or metrics.prometheusRule.default.ruler is true                         |                      |
| `metrics.prometheusRule.default.disabled.ThanosRuleQueryHighDNSFailures`                | Disable ThanosRuleQueryHighDNSFailures rule when metrics.prometheusRule.default.create or metrics.prometheusRule.default.ruler is true                        |                      |
| `metrics.prometheusRule.default.disabled.ThanosRuleAlertmanagerHighDNSFailures`         | Disable ThanosRuleAlertmanagerHighDNSFailures rule when metrics.prometheusRule.default.create or metrics.prometheusRule.default.ruler is true                 |                      |
| `metrics.prometheusRule.default.disabled.ThanosRuleNoEvaluationFor10Intervals`          | Disable ThanosRuleNoEvaluationFor10Intervals rule when metrics.prometheusRule.default.create or metrics.prometheusRule.default.ruler is true                  |                      |
| `metrics.prometheusRule.default.disabled.ThanosNoRuleEvaluations`                       | Disable ThanosNoRuleEvaluations rule when metrics.prometheusRule.default.create or metrics.prometheusRule.default.ruler is true                               |                      |
| `metrics.prometheusRule.default.disabled.ThanosSidecarBucketOperationsFailed`           | Disable ThanosSidecarBucketOperationsFailed rule when metrics.prometheusRule.default.create or metrics.prometheusRule.default.sidecar is true                 |                      |
| `metrics.prometheusRule.default.disabled.ThanosSidecarNoConnectionToStartedPrometheus`  | Disable ThanosSidecarNoConnectionToStartedPrometheus rule when metrics.prometheusRule.default.create or metrics.prometheusRule.default.sidecar is true        |                      |
| `metrics.prometheusRule.default.disabled.ThanosStoreGrpcErrorRate`                      | Disable ThanosSidecarNoConnectionToStartedPrometheus rule when metrics.prometheusRule.default.create or metrics.prometheusRule.default.store_gateway  is true |                      |
| `metrics.prometheusRule.default.disabled.ThanosStoreSeriesGateLatencyHigh`              | Disable ThanosStoreSeriesGateLatencyHigh rule when metrics.prometheusRule.default.create or metrics.prometheusRule.default.store_gateway  is true             |                      |
| `metrics.prometheusRule.default.disabled.ThanosStoreBucketHighOperationFailures`        | Disable ThanosStoreBucketHighOperationFailures rule when metrics.prometheusRule.default.create or metrics.prometheusRule.default.store_gateway  is true       |                      |
| `metrics.prometheusRule.default.disabled.ThanosStoreObjstoreOperationLatencyHigh`       | Disable ThanosStoreObjstoreOperationLatencyHigh rule when metrics.prometheusRule.default.create or metrics.prometheusRule.default.store_gateway  is true      |                      |
| `metrics.prometheusRule.default.disabled`                                               | disable one specific prometheus alert rule                                                                                                                    | `{}`                 |
| `metrics.prometheusRule.namespace`                                                      | Namespace in which the PrometheusRule CRD is created                                                                                                          | `""`                 |
| `metrics.prometheusRule.additionalLabels`                                               | Additional labels for the prometheusRule                                                                                                                      | `{}`                 |
| `metrics.prometheusRule.groups`                                                         | Prometheus Rule Groups for Thanos components                                                                                                                  | `[]`                 |

### Volume Permissions parameters

| Name                                  | Description                                                                                                                       | Value                      |
| ------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------- | -------------------------- |
| `volumePermissions.enabled`           | Enable init container that changes the owner/group of the PV mount point to `runAsUser:fsGroup`                                   | `false`                    |
| `volumePermissions.image.registry`    | Init container volume-permissions image registry                                                                                  | `REGISTRY_NAME`            |
| `volumePermissions.image.repository`  | Init container volume-permissions image repository                                                                                | `REPOSITORY_NAME/os-shell` |
| `volumePermissions.image.digest`      | Init container volume-permissions image digest in the way sha256:aa.... Please note this parameter, if set, will override the tag | `""`                       |
| `volumePermissions.image.pullPolicy`  | Init container volume-permissions image pull policy                                                                               | `IfNotPresent`             |
| `volumePermissions.image.pullSecrets` | Specify docker-registry secret names as an array                                                                                  | `[]`                       |

### MinIO&reg; chart parameters

| Name                      | Description                                                                                                                       | Value    |
| ------------------------- | --------------------------------------------------------------------------------------------------------------------------------- | -------- |
| `minio`                   | For full list of MinIO&reg; values configurations please refere [here](https://github.com/bitnami/charts/tree/main/bitnami/minio) |          |
| `minio.enabled`           | Enable/disable MinIO&reg; chart installation                                                                                      | `false`  |
| `minio.auth.rootUser`     | MinIO&reg; root username                                                                                                          | `admin`  |
| `minio.auth.rootPassword` | Password for MinIO&reg; root user                                                                                                 | `""`     |
| `minio.defaultBuckets`    | Comma, semi-colon or space separated list of MinIO&reg; buckets to create                                                         | `thanos` |

### NetWorkPolicy parameters

| Name                                       | Description                                                                                    | Value   |
| ------------------------------------------ | ---------------------------------------------------------------------------------------------- | ------- |
| `networkPolicy.enabled`                    | Enable creation of NetworkPolicy resources. Only Ingress traffic is filtered for now.          | `false` |
| `networkPolicy.allowExternal`              | Don't require client label for connections                                                     | `true`  |
| `networkPolicy.explicitNamespacesSelector` | A Kubernetes LabelSelector to explicitly select namespaces from which traffic could be allowed | `{}`    |

Specify each parameter using the `--set key=value[,key=value]` argument to `helm install`. For example,

```console
helm install my-release --set query.replicaCount=2 oci://REGISTRY_NAME/REPOSITORY_NAME/thanos
```

> Note: You need to substitute the placeholders `REGISTRY_NAME` and `REPOSITORY_NAME` with a reference to your Helm chart registry and repository. For example, in the case of Bitnami, you need to use `REGISTRY_NAME=registry-1.docker.io` and `REPOSITORY_NAME=bitnamicharts`.

The above command install Thanos chart with 2 Thanos Query replicas.

Alternatively, a YAML file that specifies the values for the parameters can be provided while installing the chart. For example,

```console
helm install my-release -f values.yaml oci://REGISTRY_NAME/REPOSITORY_NAME/thanos
```

> Note: You need to substitute the placeholders `REGISTRY_NAME` and `REPOSITORY_NAME` with a reference to your Helm chart registry and repository. For example, in the case of Bitnami, you need to use `REGISTRY_NAME=registry-1.docker.io` and `REPOSITORY_NAME=bitnamicharts`.
> **Tip**: You can use the default [values.yaml](https://github.com/bitnami/charts/tree/main/bitnami/thanos/values.yaml)

## Configuration and installation details

### [Rolling VS Immutable tags](https://docs.bitnami.com/containers/how-to/understand-rolling-tags-containers/)

It is strongly recommended to use immutable tags in a production environment. This ensures your deployment does not change automatically if the same tag is updated with a different image.

Bitnami will release a new chart updating its containers if a new version of the main container, significant changes, or critical vulnerabilities exist.

### Adding extra flags

In case you want to add extra flags to any Thanos component, you can use `XXX.extraFlags` parameter(s), where XXX is placeholder you need to replace with the actual component(s). For instance, to add extra flags to Thanos Store Gateway, use:

```yaml
storegateway:
  extraFlags:
    - --sync-block-duration=3m
    - --chunk-pool-size=2GB
```

This also works for multi-line flags. This can be useful when you want to configure caching for a particular component without using a configMap. For example, to configure the [query-range response cache of the Thanos Query Frontend](https://thanos.io/tip/components/query-frontend.md/#memcached), use:

```yaml
queryFrontend:
  extraFlags:
    - |
      --query-range.response-cache-config=
      type: MEMCACHED
      config:
        addresses:
          - <MEMCACHED_SERVER>:11211
        timeout: 500ms
        max_idle_connections: 100
        max_async_concurrency: 10
        max_async_buffer_size: 10000
        max_get_multi_concurrency: 100
        max_get_multi_batch_size: 0
        dns_provider_update_interval: 10s
        expiration: 24h
```

### Using custom Objstore configuration

This helm chart supports using custom Objstore configuration.

You can specify the Objstore configuration using the `objstoreConfig` parameter.

In addition, you can also set an external Secret with the configuration file. This is done by setting the `existingObjstoreSecret` parameter. Note that this will override the previous option. If needed you can also provide a custom Secret Key with `existingObjstoreSecretItems`, please be aware that the Path of your Secret should be `objstore.yml`.

### Using custom Query Service Discovery configuration

This helm chart supports using custom Service Discovery configuration for Query.

You can specify the Service Discovery configuration using the `query.sdConfig` parameter.

In addition, you can also set an external ConfigMap with the Service Discovery configuration file. This is done by setting the `query.existingSDConfigmap` parameter. Note that this will override the previous option.

### Using custom Ruler configuration

This helm chart supports using custom Ruler configuration.

You can specify the Ruler configuration using the `ruler.config` parameter.

In addition, you can also set an external ConfigMap with the configuration file. This is done by setting the `ruler.existingConfigmap` parameter. Note that this will override the previous option.

### Running Thanos with HTTPS and basic authentication

This helm charts supports using HTTPS and basic authentication. The underlying feature is experimental and might change in the future, so are the associated settings in the chart.
For more information, please refer to [Thanos documentation](https://thanos.io/tip/operating/https.md/#running-thanos-with-https-and-basic-authentication).

This feature can be enabled by using the following values:

- `https.enabled=true`. Enabling HTTPS requires the user to provide the TLS certificate and Key for Thanos, which can be done using one of the following options:

  - Provide a secret using `https.existingSecret`. The secret must contain the keys `tls.crt` or `tls.key` (key names can be renamed using the values `https.keyFilename` and `https.certFilename`).
  - Provide the certificate and key in your values.yaml under the values `https.cert` and `https.key`.
  - Use `https.autoGenerated=true`, using this value Helm will generate a self-signed key pair during the chart initialization. Not recommended for production environments.

- `auth.basicAuthUsers.*`. An dictionary of key / values, where the keys corresponds to the users that will have access to Thanos and the values are the plaintext passwords. Passwords will be later encrypted with bcrypt.
- Alternatively, provide your own Thanos http config file using the value `httpConfig` or `existingHttpConfigSecret`. This may cause any settings under `https.*` or `auth.*` to be ignored, except for the settings related to the TLS certificates. When providing a configuration file using these parameters, the chart Probes will fail to initialize unless one of the following fixes are applied:
  - Set `https.enabled` or `auth.basicAuthUsers` with at least one user, matching the configuration file you provided. That way Probes will be configured with HTTPS and/or basic authentication accordingly.
  - Configure your own Probes using `<component>.customLivenessProbe`, `<component>.customReadinessProbe` and `<component>.customStartupProbe`.
  - **Not recommended**. Disable the Probes.

### Store time partitions

Thanos store supports partion based on time.

Setting time partitions will create N number of store statefulsets based on the number of items in the `timePartitioning` list. Each item must contain the min and max time for querying in the supported format (find more details at [Thanos documentation](https://thanos.io/tip/components/store.md/#time-based-partitioning)).

> Note: leaving the `timePartitioning` list empty (`[]`) will create a single store for all data.

For instance, to use 3 stores you can use a **values.yaml** like the one below:

```yaml
timePartitioning:
  # One store for data older than 6 weeks
  - min: ""
    max: -6w
  # One store for data newer than 6 weeks and older than 2 weeks
  - min: -6w
    max: -2w
  # One store for data newer than 2 weeks
  - min: -2w
    max: ""
```

You can also specify different resources and limits configurations for each storegateway statefulset. This is done by adding a `resources.requests` and `resources.limits` to each item you wish to change, as shown below:

```yaml
timePartitioning:
  # One store for data older than 6 weeks
  - min: ""
    max: -6w
  # One store for data newer than 6 weeks and older than 2 weeks
  - min: -6w
    max: -2w
    resources: #optional resources declaration for partition
      requests:
        cpu: 10m
        memory: 100Mi
      limits:
        cpu: 20m
        memory: 100Mi
  # One store for data newer than 2 weeks
  - min: -2w
    max: ""
```

### Integrate Thanos with Prometheus and Alertmanager

You can integrate Thanos with Prometheus & Alertmanager using this chart and the [Bitnami kube-prometheus chart](https://github.com/bitnami/charts/tree/main/bitnami/kube-prometheus) following the steps below:

> Note: in this example we will use MinIO&reg; (subchart) as the Objstore. Every component will be deployed in the "monitoring" namespace.

- Create a **values.yaml** like the one below:

```yaml
objstoreConfig: |-
  type: s3
  config:
    bucket: thanos
    endpoint: {{ include "thanos.minio.fullname" . }}.{{ .Release.Namespace }}.svc.cluster.local:9000
    access_key: minio
    secret_key: minio123
    insecure: true
query:
  dnsDiscovery:
    sidecarsService: kube-prometheus-prometheus-thanos
    sidecarsNamespace: monitoring
bucketweb:
  enabled: true
compactor:
  enabled: true
storegateway:
  enabled: true
ruler:
  enabled: true
  alertmanagers:
    - http://kube-prometheus-alertmanager.monitoring.svc.cluster.local:9093
  config: |-
    groups:
      - name: "metamonitoring"
        rules:
          - alert: "PrometheusDown"
            expr: absent(up{prometheus="monitoring/kube-prometheus"})
metrics:
  enabled: true
  serviceMonitor:
    enabled: true
minio:
  enabled: true
  auth:
    rootPassword: minio123
    rootUser: minio
  monitoringBuckets: thanos
  accessKey:
    password: minio
  secretKey:
    password: minio123
```

- Install Prometheus Operator and Thanos charts:

For Helm 3:

```console
$ kubectl create namespace monitoring
helm install kube-prometheus \
    --set prometheus.thanos.create=true \
    --namespace monitoring \
    bitnami/kube-prometheus
helm install thanos \
    --values values.yaml \
    --namespace monitoring \
    oci://REGISTRY_NAME/REPOSITORY_NAME/thanos
```

> Note: You need to substitute the placeholders `REGISTRY_NAME` and `REPOSITORY_NAME` with a reference to your Helm chart registry and repository. For example, in the case of Bitnami, you need to use `REGISTRY_NAME=registry-1.docker.io` and `REPOSITORY_NAME=bitnamicharts`.

That's all! Now you have Thanos fully integrated with Prometheus and Alertmanager.

## Persistence

The data is persisted by default using PVC(s) on Thanos components. You can disable the persistence setting the `XXX.persistence.enabled` parameter(s) to `false`. A default `StorageClass` is needed in the Kubernetes cluster to dynamically provision the volumes. Specify another StorageClass in the `XXX.persistence.storageClass` parameter(s) or set `XXX.persistence.existingClaim` if you have already existing persistent volumes to use.

> Note: you need to substitute the XXX placeholders above with the actual component(s) you want to configure.

### Adjust permissions of persistent volume mountpoint

As the images run as non-root by default, it is necessary to adjust the ownership of the persistent volumes so that the containers can write data into it.

By default, the chart is configured to use Kubernetes Security Context to automatically change the ownership of the volumes. However, this feature does not work in all Kubernetes distributions.
As an alternative, this chart supports using an initContainer to change the ownership of the volumes before mounting it in the final destination.

You can enable this initContainer by setting `volumePermissions.enabled` to `true`.

### Deploy extra resources

There are cases where you may want to deploy extra objects, such a ConfigMap containing your app's configuration or some extra deployment with a micro service used by your app. For covering this case, the chart allows adding the full specification of other objects using the `extraDeploy` parameter.

### Setting Pod's affinity

This chart allows you to set your custom affinity using the `XXX.affinity` parameter(s). Find more information about Pod's affinity in the [kubernetes documentation](https://kubernetes.io/docs/concepts/configuration/assign-pod-node/#affinity-and-anti-affinity).

As an alternative, you can use of the preset configurations for pod affinity, pod anti-affinity, and node affinity available at the [bitnami/common](https://github.com/bitnami/charts/tree/main/bitnami/common#affinities) chart. To do so, set the `XXX.podAffinityPreset`, `XXX.podAntiAffinityPreset`, or `XXX.nodeAffinityPreset` parameters.

## Troubleshooting

Find more information about how to deal with common errors related to Bitnami's Helm charts in [this troubleshooting guide](https://docs.bitnami.com/general/how-to/troubleshoot-helm-chart-issues).

## Upgrading

### To 12.0.0

This major updates the MinIO&reg; subchart to its newest major, 12.0.0. This subchart's major doesn't include any changes affecting its use as a subchart for Thanos, so no major issues are expected during the upgrade.

### To 10.0.0

This version deprecates the usage of `MINIO_ACCESS_KEY` and `MINIO_SECRET_KEY` environment variables in MINIO&reg; container in favor of `MINIO_ROOT_USER` and `MINIO_ROOT_PASSWORD`.

If you were already using the new variables, no issues are expected during upgrade.

### To 9.0.0

This major updates the MinIO&reg; subchart to its newest major, 10.0.0. This subchart's major doesn't include any changes affecting its use as a subchart for Thanos, only needing the standard upgrade process from chart's version `8.X`.

### To 8.0.0

The chart was changed to adapt to the common Bitnami chart standards. Now it includes common elements such as sidecar and init container support, custom commands, custom liveness/readiness probes, extra environment variables support, extra pod annotations and labels, among others. In addition, other remarkable changes were to harmonize the values structure:

- The `receive.distributor.*` parameters have been renamed to `receiveDistributor.*`, and the associated manifests have been moved into its own folder. This way, Thanos Receive Distributor is treated as any other component.
- The parameter to configure TLS in the GRPC server have been restructured so they follow the `XXX.grpc.server.tls` and `XXX.grpc.client.tls` format. Previous to this change, we had different structures depending on the component.

### To 7.0.0

This major updates the MinIO&reg; subchart to its newest major, 9.0.0, which updates authentication parameters. Check [MinIO&reg; Upgrading Notes](https://github.com/bitnami/charts/tree/main/bitnami/minio#to-900) for more information.
This major release renames several values in this chart and adds missing features, in order to be inline with the rest of assets in the Bitnami charts repositor. Some of the affected values are:

- `XXX.extraEnv` parameters were renamed to `XXX.extraEnvVars`.
- `XXX.extraContainers` parameters were renamed to `XXX.sidecars`.
- `XXX.service.PROTOCOL.port` parameters were renamed to `XXX.service.ports.PROTOCOL` (e.g. `query.service.http.port` is now `query.service.ports.http`).
- `XXX.service.PROTOCOL.nodePort`parameters were renamed to `XXX.service.nodePorts.PROTOCOL` (e.g. `query.service.http.nodePort` is now `query.service.nodePorts.http`).
- `XXX.ingress.certManager` parameters were deprecated, use `XXX.ingress.annotations` to set the required annotations for CertManager instead.

### To 6.0.0

This major updates the MinIO&reg; subchart to its newest major, 8.0.0, which now has two separated services for MinIO&reg; Console and MinIO&reg; API. Check [MinIO&reg; Upgrading Notes](https://github.com/bitnami/charts/tree/main/bitnami/minio#to-800) for more information.

### To 5.4.0

This version introduces support for the receiver dual-mode implementation for Thanos [v0.22+](https://github.com/thanos-io/thanos/releases/tag/v0.22.0)

### To 5.3.0

This version introduces hash and time partitioning for the store gateway.

### To 5.0.0

This major update changes the `securityContext` interface in the `values.yaml` file.

Please note if you have changes in the `securityContext` fields those need to be migrated to `podSecurityContext`.

```diff
# ...
- securityContext:
+ podSecurityContext:
# ...
```

Other than that a new `securityContext` interface for containers got introduced `containerSecurityContext`. It's default is enabled so if you do not need it you need to opt out of it.

```diff
# ...
+ containerSecurityContext
+   enabled: true  # opt out by enabled: false
+   capabilities:
+     drop:
+     - ALL
+   runAsNonRoot: true
+   allowPrivilegeEscalation: false
+   readOnlyRootFilesystem: false
# ...
```

### To 4.0.0

This major updates the MinIO subchart to its newest major, 7.0.0, which removes previous configuration of `securityContext` and moves to `podSecurityContext` and `containerSecurityContext`.

### To 3.3.0

This version introduces `bitnami/common`, a [library chart](https://helm.sh/docs/topics/library_charts/#helm) as a dependency. More documentation about this new utility could be found [here](https://github.com/bitnami/charts/tree/main/bitnami/common#bitnami-common-library-chart). Please, make sure that you have updated the chart dependencies before executing any upgrade.

### To 3.1.0

The querier component and its settings have been renamed to query. Configuration of the query component by using keys under `querier` in your `values.yaml` will continue to work. Support for keys under `querier` will be dropped in a future release.

```text
querier.enabled                               -> query.enabled
querier.logLevel                              -> query.logLevel
querier.replicaLabel                          -> query.replicaLabel
querier.dnsDiscovery.enabled                  -> query.dnsDiscovery.enabled
querier.dnsDiscovery.sidecarsService          -> query.dnsDiscovery.sidecarsService
querier.dnsDiscovery.sidecarsNamespace        -> query.dnsDiscovery.sidecarsNamespace
querier.stores                                -> query.stores
querier.sdConfig                              -> query.sdConfig
querier.existingSDConfigmap                   -> query.existingSDConfigmap
querier.extraFlags                            -> query.extraFlags
querier.replicaCount                          -> query.replicaCount
querier.strategyType                          -> query.strategyType
querier.affinity                              -> query.affinity
querier.nodeSelector                          -> query.nodeSelector
querier.tolerations                           -> query.tolerations
querier.podLabels                             -> query.podLabels
querier.priorityClassName                     -> query.priorityClassName
querier.securityContext.enabled               -> query.securityContext.enabled
querier.securityContext.fsGroup               -> query.securityContext.fsGroup
querier.securityContext.runAsUser             -> query.securityContext.runAsUser
querier.resources.limits                      -> query.resources.limits
querier.resources.requests                    -> query.resources.requests
querier.podAnnotations                        -> query.podAnnotations
querier.livenessProbe                         -> query.livenessProbe
querier.readinessProbe                        -> query.readinessProbe
querier.grpcTLS.server.secure                 -> query.grpcTLS.server.secure
querier.grpcTLS.server.cert                   -> query.grpcTLS.server.cert
querier.grpcTLS.server.key                    -> query.grpcTLS.server.key
querier.grpcTLS.server.ca                     -> query.grpcTLS.server.ca
querier.grpcTLS.client.secure                 -> query.grpcTLS.client.secure
querier.grpcTLS.client.cert                   -> query.grpcTLS.client.cert
querier.grpcTLS.client.key                    -> query.grpcTLS.client.key
querier.grpcTLS.client.ca                     -> query.grpcTLS.client.ca
querier.grpcTLS.client.servername             -> query.grpcTLS.client.servername
querier.service.type                          -> query.service.type
querier.service.clusterIP                     -> query.service.clusterIP
querier.service.http.port                     -> query.service.http.port
querier.service.http.nodePort                 -> query.service.http.nodePort
querier.service.grpc.port                     -> query.service.grpc.port
querier.service.grpc.nodePort                 -> query.service.grpc.nodePort
querier.service.loadBalancerIP                -> query.service.loadBalancerIP
querier.service.loadBalancerSourceRanges      -> query.service.loadBalancerSourceRanges
querier.service.annotations                   -> query.service.annotations
querier.service.labelSelectorsOverride        -> query.service.labelSelectorsOverride
querier.serviceAccount.annotations            -> query.serviceAccount.annotations
querier.rbac.create                           -> query.rbac.create
querier.pspEnabled                            -> query.pspEnabled
querier.autoscaling.enabled                   -> query.autoscaling.enabled
querier.autoscaling.minReplicas               -> query.autoscaling.minReplicas
querier.autoscaling.maxReplicas               -> query.autoscaling.maxReplicas
querier.autoscaling.targetCPU                 -> query.autoscaling.targetCPU
querier.autoscaling.targetMemory              -> query.autoscaling.targetMemory
querier.pdb.create                            -> query.pdb.create
querier.pdb.minAvailable                      -> query.pdb.minAvailable
querier.pdb.maxUnavailable                    -> query.pdb.maxUnavailable
querier.ingress.enabled                       -> query.ingress.enabled
querier.ingress.certManager                   -> query.ingress.certManager
querier.ingress.hostname                      -> query.ingress.hostname
querier.ingress.annotations                   -> query.ingress.annotations
querier.ingress.tls                           -> query.ingress.tls
querier.ingress.extraHosts[0].name            -> query.ingress.extraHosts[0].name
querier.ingress.extraHosts[0].path            -> query.ingress.extraHosts[0].path
querier.ingress.extraTls[0].hosts[0]          -> query.ingress.extraTls[0].hosts[0]
querier.ingress.extraTls[0].secretName        -> query.ingress.extraTls[0].secretName
querier.ingress.secrets[0].name               -> query.ingress.secrets[0].name
querier.ingress.secrets[0].certificate        -> query.ingress.secrets[0].certificate
querier.ingress.secrets[0].key                -> query.ingress.secrets[0].key
querier.ingress.grpc.enabled                  -> query.ingress.grpc.enabled
querier.ingress.grpc.certManager              -> query.ingress.grpc.certManager
querier.ingress.grpc.hostname                 -> query.ingress.grpc.hostname
querier.ingress.grpc.annotations              -> query.ingress.grpc.annotations
querier.ingress.grpc.extraHosts[0].name       -> query.ingress.grpc.extraHosts[0].name
querier.ingress.grpc.extraHosts[0].path       -> query.ingress.grpc.extraHosts[0].path
querier.ingress.grpc.extraTls[0].hosts[0]     -> query.ingress.grpc.extraTls[0].hosts[0]
querier.ingress.grpc.extraTls[0].secretName   -> query.ingress.grpc.extraTls[0].secretName
querier.ingress.grpc.secrets[0].name          -> query.ingress.grpc.secrets[0].name
querier.ingress.grpc.secrets[0].certificate   -> query.ingress.grpc.secrets[0].certificate
querier.ingress.grpc.secrets[0].key           -> query.ingress.grpc.secrets[0].key
```

### To 3.0.0

[On November 13, 2020, Helm v2 support was formally finished](https://github.com/helm/charts#status-of-the-project), this major version is the result of the required changes applied to the Helm Chart to be able to incorporate the different features added in Helm v3 and to be consistent with the Helm project itself regarding the Helm v2 EOL.

[Learn more about this change and related upgrade considerations](https://docs.bitnami.com/kubernetes/infrastructure/mariadb/administration/upgrade-helm3/).

### To 2.4.0

The Ingress API object name for Querier changes from `{{ include "common.names.fullname" . }}` to `{{ include "common.names.fullname" . }}-querier`.

> **NOTE**: Which in most cases (depending on any set values in `fullnameOverride` or `nameOverride`) resolves to the used Helm release name (`.Release.Name`).

### To 2.0.0

The format of the chart's `extraFlags` option has been updated to be an array (instead of an object), to support passing multiple flags with the same name to Thanos.

Now you need to specify the flags in the following way in your values file (where component is one of `querier/bucketweb/compactor/storegateway/ruler`):

```yaml
component:
  ...
  extraFlags
    - --sync-block-duration=3m
    - --chunk-pool-size=2GB
```

To specify the values via CLI::

```console
--set 'component.extraFlags[0]=--sync-block-duration=3m' --set 'ruler.extraFlags[1]=--chunk-pool-size=2GB'
```

### To 1.0.0

If you are upgrading from a `<1.0.0` release you need to move your Querier Ingress information to the new values settings:

```text
ingress.enabled -> querier.ingress.enabled
ingress.certManager -> querier.ingress.certManager
ingress.hostname -> querier.ingress.hostname
ingress.annotations -> querier.ingress.annotations
ingress.extraHosts[0].name -> querier.ingress.extraHosts[0].name
ingress.extraHosts[0].path -> querier.ingress.extraHosts[0].path
ingress.extraHosts[0].hosts[0] -> querier.ingress.extraHosts[0].hosts[0]
ingress.extraHosts[0].secretName -> querier.ingress.extraHosts[0].secretName
ingress.secrets[0].name -> querier.ingress.secrets[0].name
ingress.secrets[0].certificate -> querier.ingress.secrets[0].certificate
ingress.secrets[0].key -> querier.ingress.secrets[0].key
```

## License

Copyright &copy; 2023 VMware, Inc.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

<http://www.apache.org/licenses/LICENSE-2.0>

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.